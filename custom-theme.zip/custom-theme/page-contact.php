<?php
/**
 * Template Name: Contact Us
 * 
 * Premium fully responsive Contact Us page template
 * 
 * @package Custom_Theme
 */

get_header();
?>

<main id="primary" class="builder-content-area contact-page">

    <!-- Hero Section -->
    <section class="contact-hero">
        <div class="contact-container">
            <h1 class="contact-hero-title">Get in Touch with Us</h1>
            <p class="contact-hero-subtitle">
                Have questions about our outdoor adventures or looking to plan your next thrilling getaway? We're here
                to help!<br>
                Reach out for any inquiries, rental assistance, or adventure advice.
            </p>
        </div>
    </section>

    <!-- Main Contact Section -->
    <section class="contact-main">
        <div class="contact-container">
            <div class="contact-grid">

                <!-- Left Column: Contact Form -->
                <div class="contact-form-wrapper">
                    <div class="contact-form-card">
                        <h2 class="contact-form-title">Have Questions? We're Just a Message Away!</h2>
                        <p class="contact-form-description">
                            Fill out the form below, and one of our team members will get back to you shortly.
                        </p>

                        <form class="contact-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                            method="post">
                            <input type="hidden" name="action" value="contact_form_submit">
                            <?php wp_nonce_field('contact_form_nonce', 'contact_nonce'); ?>

                            <!-- Name Fields Row -->
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first-name">First Name</label>
                                    <input type="text" id="first-name" name="first_name" placeholder="First name"
                                        required aria-required="true">
                                </div>
                                <div class="form-group">
                                    <label for="last-name">Last Name</label>
                                    <input type="text" id="last-name" name="last_name" placeholder="Last name" required
                                        aria-required="true">
                                </div>
                            </div>

                            <!-- Email -->
                            <div class="form-group">
                                <label for="email">E-mail</label>
                                <input type="email" id="email" name="email" placeholder="you@gmail.com" required
                                    aria-required="true">
                            </div>

                            <!-- Phone -->
                            <div class="form-group">
                                <label for="phone">Phone Number</label>
                                <input type="tel" id="phone" name="phone" placeholder="+1 (XXX) XXX-XXXX" required
                                    aria-required="true">
                            </div>

                            <!-- Subject -->
                            <div class="form-group">
                                <label for="subject">Subject</label>
                                <select id="subject" name="subject" required aria-required="true">
                                    <option value="">Select a message subject</option>
                                    <option value="general">General Inquiry</option>
                                    <option value="rental">Rental Assistance</option>
                                    <option value="adventure">Adventure Planning</option>
                                    <option value="support">Customer Support</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <!-- Message -->
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea id="message" name="message" rows="5" placeholder="Leave us a message..."
                                    required aria-required="true"></textarea>
                            </div>

                            <!-- Submit Button -->
                            <div class="form-submit">
                                <button type="submit" class="btn-submit">
                                    Send Message →
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Right Column: Image Card + Info Cards -->
                <div class="contact-info-wrapper">

                    <!-- Image Card -->
                    <div class="contact-image-card">
                        <div class="image-card-brand">
                            <span class="brand-icon">T</span>
                            <span class="brand-name">Thrilliz</span>
                        </div>
                        <div class="image-card-content">
                            <h3 class="image-card-title">Our experts will always help you</h3>
                            <div class="image-card-image">
                                <?php
                                // Use placeholder or custom field image
                                $contact_image = get_field('contact_image'); // ACF support
                                if ($contact_image) {
                                    echo '<img src="' . esc_url($contact_image['url']) . '" alt="' . esc_attr($contact_image['alt']) . '">';
                                } else {
                                    // Placeholder - replace with actual image path
                                    echo '<img src="' . get_template_directory_uri() . '/assets/images/contact-expert.jpg" alt="Customer support expert">';
                                }
                                ?>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Info Cards -->
                    <div class="contact-info-cards">

                        <!-- Email Card -->
                        <div class="info-card">
                            <div class="info-card-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <path
                                        d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                                    <polyline points="22,6 12,13 2,6" />
                                </svg>
                            </div>
                            <div class="info-card-content">
                                <h4 class="info-card-title">Email</h4>
                                <a href="mailto:support@thrilliz.com" class="info-card-link">support@thrilliz.com</a>
                            </div>
                        </div>

                        <!-- Phone Card -->
                        <div class="info-card">
                            <div class="info-card-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <path
                                        d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                                </svg>
                            </div>
                            <div class="info-card-content">
                                <h4 class="info-card-title">Call</h4>
                                <a href="tel:+18001553245" class="info-card-link">+1 (800) 155-3245</a>
                            </div>
                        </div>

                        <!-- Address Card -->
                        <div class="info-card">
                            <div class="info-card-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                                    <circle cx="12" cy="10" r="3" />
                                </svg>
                            </div>
                            <div class="info-card-content">
                                <h4 class="info-card-title">Address</h4>
                                <p class="info-card-text">123 Adventure Lane, Suite 103, Boulder, CO 80301</p>
                            </div>
                        </div>

                        <!-- Working Hours Card -->
                        <div class="info-card">
                            <div class="info-card-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="2">
                                    <circle cx="12" cy="12" r="10" />
                                    <polyline points="12 6 12 12 16 14" />
                                </svg>
                            </div>
                            <div class="info-card-content">
                                <h4 class="info-card-title">Working Hours</h4>
                                <p class="info-card-text">Mon-Fri: 9:00 AM - 6:00 PM (PST)</p>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <?php
    // Allow page builder content if added
    while (have_posts()):
        the_post();
        the_content();
    endwhile;
    ?>

</main>

<?php
get_footer();
