<?php
/**
 * Template Name: Page Builder (Full Width)
 * Description: Clean template for page builders (Elementor, Gutenberg, etc.) with no content restrictions
 * 
 * @package Custom_Theme
 */

get_header();
?>

<main id="primary" class="builder-content-area">
    <?php
    while (have_posts()):
        the_post();

        // Output page content - No wrappers, no containers
        the_content();

        // Optional: Page links for multi-page content
        wp_link_pages(
            array(
                'before' => '<div class="page-links">' . esc_html__('Pages:', 'custom-theme'),
                'after' => '</div>',
            )
        );

    endwhile; // End of the loop
    ?>
</main>

<?php
get_footer();
