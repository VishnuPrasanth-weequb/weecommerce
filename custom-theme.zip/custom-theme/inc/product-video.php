<?php
/**
 * Product Video Feature
 * Adds a custom field for Video URL and handles frontend rendering in the gallery.
 */

if (!defined('ABSPATH')) {
    exit;
}

// 1. Add Custom Field to General Tab
add_action('woocommerce_product_options_general_product_data', 'custom_theme_add_video_field');
function custom_theme_add_video_field()
{
    echo '<div class="options_group">';

    woocommerce_wp_text_input(array(
        'id' => '_product_video_url',
        'label' => __('Product Video URL', 'custom-theme'),
        'placeholder' => 'https://example.com/video.mp4 or YouTube/Vimeo URL',
        'desc_tip' => 'true',
        'description' => __('Enter a direct MP4 link or YouTube/Vimeo URL to display a video in place of the main product image.', 'custom-theme')
    ));

    echo '</div>';
}

// 2. Save Custom Field
add_action('woocommerce_process_product_meta', 'custom_theme_save_video_field');
function custom_theme_save_video_field($post_id)
{
    $video_url = isset($_POST['_product_video_url']) ? esc_url_raw($_POST['_product_video_url']) : '';
    update_post_meta($post_id, '_product_video_url', $video_url);
}

// 3. Inject Video into Gallery (Main Image)
// We filter the first image html to conditionally wrap or replace it
add_filter('woocommerce_single_product_image_thumbnail_html', 'custom_theme_render_video_in_gallery', 10, 2);

function custom_theme_render_video_in_gallery($html, $post_thumbnail_id)
{
    // Only target the main image (post_thumbnail_id matches main product image)
    global $product;

    if (!is_product())
        return $html;

    $video_url = get_post_meta($product->get_id(), '_product_video_url', true);

    // Safety check: only if video exists and we are rendering the featured image (first one)
    // Complex check: WC doesn't pass "index", but we can try to detect if it's the main wrapper.
    // Actually, this filter runs for thumbnails too. 
    // We only want to affect the MAIN image when it's initially rendered or if it's the first slide.

    if (empty($video_url))
        return $html;

    // Check if this is the featured image
    if ($product->get_image_id() == $post_thumbnail_id) {

        // Basic MP4 support for now
        if (strpos($video_url, '.mp4') !== false) {
            $video_html = '<div class="product-video-wrapper" style="position:relative; width:100%; height:100%;">';
            $video_html .= '<video width="100%" height="auto" controls autoplay muted loop playsinline style="border-radius:12px; display:block;">';
            $video_html .= '<source src="' . esc_url($video_url) . '" type="video/mp4">';
            $video_html .= 'Your browser does not support the video tag.';
            $video_html .= '</video>';
            $video_html .= '</div>';

            // Return video INSTEAD of image? Or wrapped?
            // If we replace fully, zoom might break. 
            // Better to wrap in a way that respects layout.
            // For correct "Gallery" behavior, it should be a slide. 

            return '<div class="woocommerce-product-gallery__image" data-thumb="' . wp_get_attachment_image_url($post_thumbnail_id, 'thumbnail') . '">' . $video_html . '</div>';
        }

        // YouTube/Vimeo Embed (Simple Iframe)
        if (strpos($video_url, 'youtube') !== false || strpos($video_url, 'vimeo') !== false) {
            // Convert to Embed URL logic simplified for demo
            // Real implementation needs regex to extract ID
            $embed_url = $video_url; // Placeholder, assuming user provides embed friendly url or we use regex

            if (strpos($video_url, 'watch?v=') !== false) {
                $embed_url = str_replace('watch?v=', 'embed/', $video_url);
            }

            $video_html = '<div class="product-video-wrapper" style="position:relative; padding-bottom:100%; height:0; overflow:hidden; border-radius:12px;">';
            $video_html .= '<iframe src="' . esc_url($embed_url) . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="position:absolute; top:0; left:0; width:100%; height:100%;"></iframe>';
            $video_html .= '</div>';

            return '<div class="woocommerce-product-gallery__image" data-thumb="' . wp_get_attachment_image_url($post_thumbnail_id, 'thumbnail') . '">' . $video_html . '</div>';
        }
    }

    return $html;
}
