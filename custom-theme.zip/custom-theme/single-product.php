<?php
/**
 * The Template for displaying all single products
 *
 * @package Custom_Theme
 */

defined('ABSPATH') || exit;

get_header();

?>
<div class="container main-content">
    <?php
    while (have_posts()):
        the_post();
        wc_get_template_part('content', 'single-product');
    endwhile; // end of the loop.
    ?>
</div>
<?php
get_footer();
