/**
 * PWA Registration Script v3.0.0
 * Network-first for HTML, cache-first for assets
 */
(function () {
    'use strict';

    // Check browser support
    if (!('serviceWorker' in navigator)) {
        console.warn('[PWA] Service Workers not supported in this browser');
        return;
    }

    // Force unregister old service workers and clear caches
    window.addEventListener('load', function () {
        // Clear old service worker registrations
        navigator.serviceWorker.getRegistrations().then(function (registrations) {
            registrations.forEach(function (registration) {
                console.log('[PWA] Unregistering old service worker');
                registration.unregister();
            });

            // Clear all caches
            if ('caches' in window) {
                caches.keys().then(function (cacheNames) {
                    return Promise.all(
                        cacheNames.map(function (cacheName) {
                            console.log('[PWA] Deleting cache:', cacheName);
                            return caches.delete(cacheName);
                        })
                    );
                }).then(function () {
                    console.log('[PWA] All caches cleared, registering new service worker');
                    registerServiceWorker();
                });
            } else {
                registerServiceWorker();
            }
        });
    });

    function registerServiceWorker() {
        navigator.serviceWorker.register('/service-worker.js', {
            scope: '/'
        })
            .then(function (registration) {
                console.log('[PWA] Service Worker v3.0.0 registered successfully');
                console.log('[PWA] Scope:', registration.scope);
                console.log('[PWA] Strategy: Network-first for HTML, Cache-first for assets');

                // Force immediate activation
                if (registration.waiting) {
                    registration.waiting.postMessage({ type: 'SKIP_WAITING' });
                }

                // Check for updates every 30 seconds
                setInterval(function () {
                    registration.update();
                }, 30000);

                // Handle update found
                registration.addEventListener('updatefound', function () {
                    const newWorker = registration.installing;
                    console.log('[PWA] New service worker found, installing...');

                    newWorker.addEventListener('statechange', function () {
                        console.log('[PWA] Service Worker state:', newWorker.state);

                        if (newWorker.state === 'installed') {
                            if (navigator.serviceWorker.controller) {
                                console.log('[PWA] New version available! Activating...');
                                newWorker.postMessage({ type: 'SKIP_WAITING' });
                                // Reload page to activate new service worker
                                window.location.reload();
                            } else {
                                console.log('[PWA] Service Worker activated for first time');
                            }
                        }
                    });
                });
            })
            .catch(function (error) {
                console.error('[PWA] Service Worker registration failed:', error);
            });

        // Log controller changes
        navigator.serviceWorker.addEventListener('controllerchange', function () {
            console.log('[PWA] Service Worker controller changed - new version active');
        });
    }

    // Handle install prompt
    let deferredPrompt = null;

    window.addEventListener('beforeinstallprompt', function (event) {
        console.log('[PWA] Install prompt available');
        event.preventDefault();
        deferredPrompt = event;
        window.dispatchEvent(new CustomEvent('pwa-install-available', {
            detail: { prompt: deferredPrompt }
        }));
    });

    window.addEventListener('appinstalled', function (event) {
        console.log('[PWA] App installed successfully!');
        deferredPrompt = null;
        window.dispatchEvent(new CustomEvent('pwa-installed'));
    });

    // Global function to trigger install prompt
    window.showPWAInstallPrompt = function () {
        if (!deferredPrompt) {
            console.log('[PWA] Install prompt not available');
            return;
        }

        deferredPrompt.prompt();

        deferredPrompt.userChoice.then(function (choiceResult) {
            if (choiceResult.outcome === 'accepted') {
                console.log('[PWA] User accepted the install prompt');
            } else {
                console.log('[PWA] User dismissed the install prompt');
            }
            deferredPrompt = null;
        });
    };

    // Log PWA display mode
    window.addEventListener('DOMContentLoaded', function () {
        const displayMode = window.matchMedia('(display-mode: standalone)').matches
            ? 'standalone'
            : 'browser';
        console.log('[PWA] Display mode:', displayMode);

        if (displayMode === 'standalone') {
            document.body.classList.add('pwa-standalone');
        }
    });
})();
