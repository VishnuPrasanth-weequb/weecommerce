// Header scroll effect
jQuery(document).ready(function ($) {
    const header = $('.premium-header');

    $(window).on('scroll', function () {
        if ($(window).scrollTop() > 50) {
            header.addClass('scrolled');
        } else {
            header.removeClass('scrolled');
        }
    });

    // Mobile menu drawer toggle
    const mobileMenuToggle = $('.mobile-menu-toggle');
    const mobileMenuDrawer = $('#mobile-menu-drawer');
    const mobileMenuOverlay = $('.mobile-menu-overlay');

    mobileMenuToggle.on('click', function () {
        const isExpanded = $(this).attr('aria-expanded') === 'true';

        // Toggle aria-expanded
        $(this).attr('aria-expanded', !isExpanded);

        // Toggle drawer and overlay
        mobileMenuDrawer.toggleClass('is-open');
        mobileMenuOverlay.toggleClass('is-active');

        // Prevent body scroll when menu is open
        if (!isExpanded) {
            $('body').css('overflow', 'hidden');
        } else {
            $('body').css('overflow', '');
        }
    });

    // Close menu when clicking overlay
    mobileMenuOverlay.on('click', function () {
        mobileMenuDrawer.removeClass('is-open');
        mobileMenuOverlay.removeClass('is-active');
        mobileMenuToggle.attr('aria-expanded', 'false');
        $('body').css('overflow', '');
    });

    // Close menu when clicking a link
    mobileMenuDrawer.find('a').on('click', function () {
        mobileMenuDrawer.removeClass('is-open');
        mobileMenuOverlay.removeClass('is-active');
        mobileMenuToggle.attr('aria-expanded', 'false');
        $('body').css('overflow', '');
    });
});
