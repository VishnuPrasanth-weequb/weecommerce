jQuery(document).ready(function ($) {
    /**
     * AJAX Add to Cart for Single Product Page
     * Intercepts the "Add to Cart" button click to prevent reload and triggers slide drawer.
     */
    $('body').on('click', '.single_add_to_cart_button:not(.buy_now_button)', function (e) {
        var $thisbutton = $(this),
            $form = $thisbutton.closest('form.cart');

        // If button is disabled (invalid variation), let WC handle it
        if ($thisbutton.is('.disabled')) {
            console.log('Add to cart button is disabled');
            return;
        }

        e.preventDefault();

        console.log('AJAX Add to Cart triggered');

        var product_id = $form.find('input[name=product_id]').val() || $thisbutton.val();
        var quantity = $form.find('input[name=quantity]').val() || 1;
        var variation_id = $form.find('input[name=variation_id]').val() || 0;

        // Serialize all form data
        var formData = $form.serializeArray();

        console.log('Product ID:', product_id, 'Quantity:', quantity, 'Variation:', variation_id);

        $thisbutton.removeClass('added').addClass('loading');

        // Trigger custom event
        $(document.body).trigger('adding_to_cart', [$thisbutton, formData]);

        $.ajax({
            type: 'POST',
            url: wc_add_to_cart_params.ajax_url,
            data: {
                action: 'woocommerce_ajax_add_to_cart',
                product_id: product_id,
                product_sku: '',
                quantity: quantity,
                variation_id: variation_id,
            },
            success: function (response) {
                console.log('AJAX Success:', response);

                if (!response) {
                    console.error('Empty response from server');
                    return;
                }

                if (response.error && response.product_url) {
                    window.location = response.product_url;
                    return;
                }

                $thisbutton.removeClass('loading').addClass('added');

                // Trigger fragment refresh to update cart
                $(document.body).trigger('wc_fragment_refresh');

                // Open cart drawer after a short delay
                setTimeout(function () {
                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $thisbutton]);
                    console.log('Cart drawer should open now');
                }, 300);

                // Suppress WooCommerce notices
                setTimeout(function () {
                    $('.woocommerce-notices-wrapper, .woocommerce-message').remove();
                }, 100);
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', status, error);
                console.error('Response:', xhr.responseText);
                $thisbutton.removeClass('loading');

                // Show error to user
                alert('Failed to add product to cart. Please try again.');
            }
        });
    });
});
