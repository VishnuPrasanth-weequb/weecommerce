/**
 * Checkout Cart Editor
 * Handles quantity updates and product removal on the checkout page
 */

(function ($) {
    'use strict';

    const CheckoutCartEditor = {
        init: function () {
            this.injectControls();
            this.bindEvents();
        },

        injectControls: function () {
            // Find all product items in the order review
            const $items = $('.woocommerce-checkout-review-order-table .cart_item, .wc-block-components-order-summary-item');

            $items.each(function () {
                const $item = $(this);
                const $qty = $item.find('.product-quantity');
                const cartItemKey = $item.data('cart-item-key') || $item.find('[data-cart-item-key]').data('cart-item-key');

                // Skip if controls already exist
                if ($item.find('.qty-controls').length > 0) {
                    return;
                }

                // Get current quantity
                let currentQty = 1;
                const qtyMatch = $qty.text().match(/×\s*(\d+)/);
                if (qtyMatch) {
                    currentQty = parseInt(qtyMatch[1]);
                }

                // Create quantity controls
                const controlsHTML = `
                    <div class="qty-controls" data-cart-key="${cartItemKey}">
                        <button type="button" class="qty-btn qty-minus" aria-label="Decrease quantity">−</button>
                        <span class="qty-display">${currentQty}</span>
                        <button type="button" class="qty-btn qty-plus" aria-label="Increase quantity">+</button>
                    </div>
                    <button type="button" class="remove-item" data-cart-key="${cartItemKey}" aria-label="Remove item">×</button>
                `;

                // Insert controls after product name
                $item.find('.product-name, .wc-block-components-order-summary-item__description').first().after(controlsHTML);
            });
        },

        bindEvents: function () {
            const self = this;

            // Quantity increase
            $(document).on('click', '.qty-plus', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const $controls = $btn.closest('.qty-controls');
                const cartKey = $controls.data('cart-key');
                const $display = $controls.find('.qty-display');
                const newQty = parseInt($display.text()) + 1;

                self.updateQuantity(cartKey, newQty, $controls);
            });

            // Quantity decrease
            $(document).on('click', '.qty-minus', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const $controls = $btn.closest('.qty-controls');
                const cartKey = $controls.data('cart-key');
                const $display = $controls.find('.qty-display');
                const currentQty = parseInt($display.text());

                if (currentQty > 1) {
                    self.updateQuantity(cartKey, currentQty - 1, $controls);
                } else {
                    // Ask for confirmation before removing
                    if (confirm('Remove this item from your order?')) {
                        self.removeItem(cartKey, $controls.closest('.cart_item, .wc-block-components-order-summary-item'));
                    }
                }
            });

            // Remove item
            $(document).on('click', '.remove-item', function (e) {
                e.preventDefault();
                const $btn = $(this);
                const cartKey = $btn.data('cart-key');
                const $item = $btn.closest('.cart_item, .wc-block-components-order-summary-item');

                if (confirm('Remove this item from your order?')) {
                    self.removeItem(cartKey, $item);
                }
            });
        },

        updateQuantity: function (cartKey, newQty, $controls) {
            $controls.addClass('loading');

            $.ajax({
                type: 'POST',
                url: wc_checkout_params.ajax_url,
                data: {
                    action: 'update_cart_item_qty',
                    cart_item_key: cartKey,
                    quantity: newQty,
                    security: wc_checkout_params.update_cart_nonce || ''
                },
                success: function (response) {
                    if (response.success) {
                        // Update display
                        $controls.find('.qty-display').text(newQty);

                        // Trigger WooCommerce checkout update
                        $(document.body).trigger('update_checkout');
                    } else {
                        alert(response.data.message || 'Failed to update quantity');
                    }
                },
                error: function () {
                    alert('An error occurred. Please try again.');
                },
                complete: function () {
                    $controls.removeClass('loading');
                }
            });
        },

        removeItem: function (cartKey, $item) {
            $item.addClass('removing');

            $.ajax({
                type: 'POST',
                url: wc_checkout_params.ajax_url,
                data: {
                    action: 'remove_cart_item',
                    cart_item_key: cartKey,
                    security: wc_checkout_params.update_cart_nonce || ''
                },
                success: function (response) {
                    if (response.success) {
                        // Fade out and remove
                        $item.fadeOut(300, function () {
                            $(this).remove();
                            // Update checkout
                            $(document.body).trigger('update_checkout');
                        });
                    } else {
                        $item.removeClass('removing');
                        alert(response.data.message || 'Failed to remove item');
                    }
                },
                error: function () {
                    $item.removeClass('removing');
                    alert('An error occurred. Please try again.');
                }
            });
        }
    };

    // Initialize when document is ready
    $(document).ready(function () {
        CheckoutCartEditor.init();
    });

    // Re-initialize after AJAX updates
    $(document.body).on('updated_checkout', function () {
        setTimeout(function () {
            CheckoutCartEditor.injectControls();
        }, 500);
    });

})(jQuery);
