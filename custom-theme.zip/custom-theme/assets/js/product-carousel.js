/**
 * Premium Product Carousel Logic
 * Handles horizontal scrolling and navigation state
 */

document.addEventListener('DOMContentLoaded', function () {
    initProductCarousels();
});

function initProductCarousels() {
    const wrappers = document.querySelectorAll('.product-carousel-wrapper-premium');

    wrappers.forEach(wrapper => {
        const track = wrapper.querySelector('.product-carousel-track');
        const skeleton = wrapper.querySelector('.product-carousel-skeleton');
        const prevBtn = wrapper.querySelector('.carousel-btn.prev');
        const nextBtn = wrapper.querySelector('.carousel-btn.next');

        if (!track || !prevBtn || !nextBtn) return;

        // --- PERFORMANCE: Skeleton Removal ---
        // Ensure initial layout is painted before revealing
        // Real-world emulation: wait for main thread to clear
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                // Add ready class to real track (fades in)
                track.classList.add('is-ready');

                // Hide skeleton (fades out)
                if (skeleton) {
                    skeleton.classList.add('is-hidden');

                    // Optional: remove from DOM after transition to free memory
                    // setTimeout(() => skeleton.remove(), 600); 
                    // Keeping it allows for potential reuse or non-destructive state
                }
            });
        });

        // Initial Button State
        updateButtonState(track, prevBtn, nextBtn);

        // Scroll Event Listener (Debounced for performance)
        let scrollTimeout;
        track.addEventListener('scroll', () => {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                updateButtonState(track, prevBtn, nextBtn);
            }, 50);
        });

        // Click Listeners
        prevBtn.addEventListener('click', () => {
            scrollTrack(track, 'left');
        });

        nextBtn.addEventListener('click', () => {
            scrollTrack(track, 'right');
        });
    });
}

/**
 * Calculates scroll distance based on container width
 * @param {HTMLElement} track 
 * @param {string} direction 'left' or 'right'
 */
function scrollTrack(track, direction) {
    const containerWidth = track.clientWidth;
    // Scroll roughly one "page" or screen width, aligned to items
    // Since we use scroll-snap, we can just scroll by container width
    // and let CSS snap handle the perfect alignment.

    // Fine tune: scroll 75% of width to ensure visibility of next/prev context
    const scrollAmount = containerWidth * 0.75;

    if (direction === 'left') {
        track.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
        track.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
}

/**
 * Disables arrows based on scroll position
 */
function updateButtonState(track, prevBtn, nextBtn) {
    const scrollLeft = Math.ceil(track.scrollLeft);
    const maxScrollLeft = Math.ceil(track.scrollWidth - track.clientWidth);

    // Tolerance of 2px for math rounding errs
    prevBtn.disabled = scrollLeft <= 2;
    nextBtn.disabled = scrollLeft >= maxScrollLeft - 2;
}
