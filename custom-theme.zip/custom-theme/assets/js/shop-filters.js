/**
 * Premium Shop Filters - Production Grade
 * Handles AJAX filtering with WooCommerce integration
 */

(function ($) {
    'use strict';

    // State Management
    const FilterController = {
        state: {
            product_cat: [],
            product_tag: [],
            min_price: '',
            max_price: '',
            stock_status: [],
            on_sale: false,
            sort: 'menu_order',
            paged: 1 // Init Page
        },
        maxPages: 1, // Init Max Pages

        init: function () {
            console.log('[Shop Filters] Initializing...');
            this.cacheElements();
            this.bindEvents();
            this.initAccordions();
            this.loadStateFromURL();
            this.initPagination(); // Check if we need button on load
            this.updateChips();
        },

        cacheElements: function () {
            this.$container = $('#premium-filters');
            this.$results = $('#shop-results-container');
            this.$chips = $('#active-filter-chips');
            this.$mobilePanel = $('#filters-panel');
            this.$overlay = $('#filters-overlay');
            this.$sortSelect = $('#shop-sort-select');
        },

        bindEvents: function () {
            const self = this;

            // Sort
            this.$sortSelect.on('change', function () {
                self.state.sort = $(this).val();
                self.applyFilters();
            });

            // Checkboxes (delegated)
            this.$container.on('change', 'input[type="checkbox"]', function () {
                self.handleCheckboxChange($(this));
            });

            // Price Apply
            $(document).on('click', '#apply-price-btn', function (e) {
                e.preventDefault();
                self.state.min_price = $('input[name="min_price"]').val();
                self.state.max_price = $('input[name="max_price"]').val();
                self.applyFilters();
            });

            // Mobile Trigger
            $(document).on('click', '#mobile-filter-trigger', function (e) {
                e.preventDefault();
                self.openMobileDrawer();
            });

            // Close Drawer
            $(document).on('click', '#close-filters, .btn-close-filters, #filters-overlay', function (e) {
                e.preventDefault();
                self.closeMobileDrawer();
            });

            // Mobile Actions
            $('#apply-filters-mobile').on('click', function () {
                self.applyFilters();
                self.closeMobileDrawer();
            });

            $('#clear-all-mobile').on('click', function () {
                self.resetFilters();
                self.applyFilters();
                self.closeMobileDrawer();
            });

            // Chip Removal
            $(document).on('click', '.filter-chip', function () {
                self.removeChip($(this));
            });

            // Accordion Toggle
            $(document).on('click', '.filter-accordion-header', function (e) {
                e.preventDefault();
                self.toggleAccordion($(this).closest('.filter-accordion'));
            });

            // Load More Button
            $(document).on('click', '#load-more-btn', function (e) {
                e.preventDefault();
                self.applyFilters(true); // Is Load More = true
            });
        },

        initPagination: function () {
            // If we are on page 1, we might need a button if total pages > 1
            // We can grasp this from a global variable if set, or just default to 1 and wait for first ajax
            // Ideally, the PHP should pass `max_num_pages` to JS via localize_script
            // For now, let's assume if there are items, we might check via an initial AJAX call OR just let the user filter first
            // Actually, if static load has > 9 items, standard pagination shows. We need to hide standard and show ours.
            // For MVP, we can just hide standard pagination via CSS and rely on filters to reset.
            // OR: we can check provided localData if added.
        },

        initAccordions: function () {
            // All accordions closed by default on page load
            // User can click to open any accordion
            $('.filter-accordion').removeClass('active');
        },

        toggleAccordion: function ($accordion) {
            const isActive = $accordion.hasClass('active');

            // Close all accordions
            $('.filter-accordion').removeClass('active');

            // If the clicked accordion was not active, open it
            if (!isActive) {
                $accordion.addClass('active');
            }
        },

        handleCheckboxChange: function ($checkbox) {
            const name = $checkbox.attr('name');
            const value = $checkbox.val();
            const isChecked = $checkbox.is(':checked');

            if (name === 'product_cat') {
                if (isChecked) {
                    this.state.product_cat.push(value);
                } else {
                    this.state.product_cat = this.state.product_cat.filter(v => v !== value);
                }
            } else if (name === 'product_tag') {
                if (isChecked) {
                    this.state.product_tag.push(value);
                } else {
                    this.state.product_tag = this.state.product_tag.filter(v => v !== value);
                }
            } else if (name === 'stock_status') {
                if (isChecked) {
                    this.state.stock_status.push(value);
                } else {
                    this.state.stock_status = this.state.stock_status.filter(v => v !== value);
                }
            } else if (name === 'on_sale') {
                this.state.on_sale = isChecked;
            }

            // Auto-apply on desktop
            if (window.innerWidth >= 1024) {
                this.applyFilters();
            }
        },

        applyFilters: function (isLoadMore = false) {
            console.log('[Shop Filters] Applying filters:', this.state);

            // Reset page if not loading more
            if (!isLoadMore) {
                this.state.paged = 1;
                this.$results.removeClass('loading-more');
                this.$results.addClass('loading');
            } else {
                this.state.paged++;
                $('#load-more-btn').addClass('loading');
            }

            this.updateURL();
            this.updateChips();

            $.ajax({
                url: '/wp-admin/admin-ajax.php',
                type: 'POST',
                data: {
                    action: 'custom_filter_shop',
                    filters: this.state,
                    paged: this.state.paged,
                    nonce: '<?php echo wp_create_nonce("shop_filter_nonce"); ?>'
                },
                success: (response) => {
                    if (response.success) {

                        // Append or Replace
                        if (isLoadMore) {
                            // Find product grid in response and append items
                            const $newContent = $(response.data.html);
                            // If response contains UL/LI structure, extract LIs
                            // Assuming response.data.html is the full loop which might include UL wrapper
                            // We need to parse it carefully.
                            // However, we just grab everything if it's simpler or replace innerHTML of grid

                            // Better approach: User PHP sends clean HTML or we assume the structure
                            // Standard Loop returns <ul>...</ul> or just content depending on tempalte
                            // We'll append the content inside the existing grid
                            const $grid = this.$results.find('ul.products');
                            $grid.append($(response.data.html).find('li.product'));

                        } else {
                            this.$results.html(response.data.html);
                        }

                        // Update Count
                        if (response.data.count !== undefined) {
                            $('#filter-result-count').text(response.data.count);
                        }

                        // Handle Load More Button Visibility
                        this.maxPages = response.data.max_pages || 1;
                        this.updateLoadMoreButton();

                    } else {
                        console.error('[Shop Filters] Error:', response);
                    }
                },
                error: (xhr, status, error) => {
                    console.error('[Shop Filters] AJAX Error:', error);
                    // alert('Filter request failed. Please refresh the page.'); 
                },
                complete: () => {
                    this.$results.removeClass('loading');
                    $('#load-more-btn').removeClass('loading');
                }
            });
        },

        updateLoadMoreButton: function () {
            // Remove existing button if any
            $('#load-more-container').remove();

            // Check if we need a button
            if (this.state.paged < this.maxPages) {
                const buttonHtml = `
                    <div id="load-more-container" style="text-align: center; margin-top: 40px; width: 100%;">
                        <button id="load-more-btn" class="btn btn-secondary" style="min-width: 200px;">
                            ${'Load More'}
                        </button>
                    </div>
                `;
                this.$results.append(buttonHtml);
            }
        },

        updateURL: function () {
            const params = new URLSearchParams();

            if (this.state.product_cat.length) params.set('product_cat', this.state.product_cat.join(','));
            if (this.state.product_tag.length) params.set('product_tag', this.state.product_tag.join(','));
            if (this.state.min_price) params.set('min_price', this.state.min_price);
            if (this.state.max_price) params.set('max_price', this.state.max_price);
            if (this.state.stock_status.length) params.set('stock_status', this.state.stock_status.join(','));
            if (this.state.on_sale) params.set('on_sale', 'true');
            if (this.state.sort !== 'menu_order') params.set('orderby', this.state.sort);

            const newURL = window.location.pathname + (params.toString() ? '?' + params.toString() : '');

            if (window.history.pushState) {
                window.history.pushState({ filters: this.state }, '', newURL);
            }
        },

        updateChips: function () {
            let html = '';

            // Categories
            this.state.product_cat.forEach(slug => {
                const label = $(`input[name="product_cat"][value="${slug}"]`).siblings('.label-text').text() || slug;
                html += `<span class="filter-chip" data-type="cat" data-value="${slug}">${label} <span class="remove">×</span></span>`;
            });

            // Tags
            this.state.product_tag.forEach(slug => {
                const label = $(`input[name="product_tag"][value="${slug}"]`).siblings('.label-text').text() || slug;
                html += `<span class="filter-chip" data-type="tag" data-value="${slug}">${label} <span class="remove">×</span></span>`;
            });

            // Price
            if (this.state.min_price || this.state.max_price) {
                const min = this.state.min_price || '0';
                const max = this.state.max_price || '∞';
                html += `<span class="filter-chip" data-type="price">₹${min} - ${max} <span class="remove">×</span></span>`;
            }

            // Sale
            if (this.state.on_sale) {
                html += `<span class="filter-chip" data-type="sale">On Sale <span class="remove">×</span></span>`;
            }

            this.$chips.html(html);
        },

        removeChip: function ($chip) {
            const type = $chip.data('type');
            const value = $chip.data('value');

            if (type === 'cat') {
                this.state.product_cat = this.state.product_cat.filter(v => v !== value);
                $(`input[name="product_cat"][value="${value}"]`).prop('checked', false);
            } else if (type === 'tag') {
                this.state.product_tag = this.state.product_tag.filter(v => v !== value);
                $(`input[name="product_tag"][value="${value}"]`).prop('checked', false);
            } else if (type === 'price') {
                this.state.min_price = '';
                this.state.max_price = '';
                $('input[name="min_price"], input[name="max_price"]').val('');
            } else if (type === 'sale') {
                this.state.on_sale = false;
                $('input[name="on_sale"]').prop('checked', false);
            }

            this.applyFilters();
        },

        resetFilters: function () {
            this.state = {
                product_cat: [],
                product_tag: [],
                min_price: '',
                max_price: '',
                stock_status: [],
                on_sale: false,
                sort: this.state.sort
            };

            this.$container.find('input[type="checkbox"]').prop('checked', false);
            $('input[name="min_price"], input[name="max_price"]').val('');
        },

        loadStateFromURL: function () {
            const params = new URLSearchParams(window.location.search);

            if (params.has('product_cat')) {
                this.state.product_cat = params.get('product_cat').split(',');
                this.state.product_cat.forEach(slug => {
                    $(`input[name="product_cat"][value="${slug}"]`).prop('checked', true);
                });
            }

            if (params.has('product_tag')) {
                this.state.product_tag = params.get('product_tag').split(',');
                this.state.product_tag.forEach(slug => {
                    $(`input[name="product_tag"][value="${slug}"]`).prop('checked', true);
                });
            }

            if (params.has('min_price')) {
                this.state.min_price = params.get('min_price');
                $('input[name="min_price"]').val(this.state.min_price);
            }

            if (params.has('max_price')) {
                this.state.max_price = params.get('max_price');
                $('input[name="max_price"]').val(this.state.max_price);
            }

            if (params.has('orderby')) {
                this.state.sort = params.get('orderby');
                this.$sortSelect.val(this.state.sort);
            }

            if (params.has('on_sale')) {
                this.state.on_sale = true;
                $('input[name="on_sale"]').prop('checked', true);
            }
        },

        openMobileDrawer: function () {
            this.$mobilePanel.addClass('open');
            this.$overlay.addClass('visible');
            $('body').css('overflow', 'hidden');
        },

        closeMobileDrawer: function () {
            this.$mobilePanel.removeClass('open');
            this.$overlay.removeClass('visible');
            $('body').css('overflow', '');
        }
    };

    // Initialize on ready
    $(document).ready(function () {
        FilterController.init();
    });

})(jQuery);
