/**
 * Premium Cinematic Smoke Background
 * GSAP + Canvas Implementation
 * Ultra-slow, organic, performance-optimized
 */

class SmokeBackground {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        if (!this.canvas) return;

        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.time = 0;
        this.targetFPS = 60;
        this.actualFPS = 60;
        this.maxParticles = 25;

        this.init();
    }

    init() {
        this.resize();
        this.createParticles();
        this.animate();

        // Handle resize
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();

        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;

        this.ctx.scale(dpr, dpr);

        this.width = rect.width;
        this.height = rect.height;

        // Adjust particle count based on screen size
        if (this.width < 768) {
            this.maxParticles = 15;
        } else if (this.width < 1200) {
            this.maxParticles = 20;
        }
    }

    createParticles() {
        this.particles = [];

        // Create 3 depth layers
        const layers = 3;
        const particlesPerLayer = Math.floor(this.maxParticles / layers);

        for (let layer = 0; layer < layers; layer++) {
            const depthFactor = (layer + 1) / layers;

            for (let i = 0; i < particlesPerLayer; i++) {
                this.particles.push({
                    x: Math.random() * this.width,
                    y: Math.random() * this.height,
                    size: (80 + Math.random() * 200) * depthFactor,
                    speedY: (0.08 + Math.random() * 0.12) * depthFactor,
                    speedX: (Math.random() - 0.5) * 0.15 * depthFactor,
                    opacity: 0.03 + Math.random() * 0.05,
                    layer: layer,
                    offset: Math.random() * Math.PI * 2,
                    noiseScale: 0.001 + Math.random() * 0.002,
                    blur: 18 + Math.random() * 6
                });
            }
        }
    }

    update() {
        this.time += 0.01;

        this.particles.forEach(particle => {
            // Organic noise-based movement
            const noiseX = Math.sin(this.time * particle.noiseScale + particle.offset) * 0.3;
            const noiseY = Math.cos(this.time * particle.noiseScale * 0.7 + particle.offset) * 0.2;

            // Update position with ultra-slow drift
            particle.x += particle.speedX + noiseX;
            particle.y -= particle.speedY + noiseY;

            // Wrap around screen
            if (particle.y + particle.size < 0) {
                particle.y = this.height + particle.size;
                particle.x = Math.random() * this.width;
            }
            if (particle.x + particle.size < 0) {
                particle.x = this.width + particle.size;
            }
            if (particle.x - particle.size > this.width) {
                particle.x = -particle.size;
            }
        });
    }

    draw() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.width, this.height);

        // Sort by layer (draw back to front)
        const sorted = [...this.particles].sort((a, b) => a.layer - b.layer);

        sorted.forEach(particle => {
            this.ctx.save();

            // Apply blur
            this.ctx.filter = `blur(${particle.blur}px)`;

            // Create radial gradient
            const gradient = this.ctx.createRadialGradient(
                particle.x, particle.y, 0,
                particle.x, particle.y, particle.size
            );

            gradient.addColorStop(0, `rgba(255, 255, 255, ${particle.opacity})`);
            gradient.addColorStop(0.5, `rgba(245, 245, 245, ${particle.opacity * 0.5})`);
            gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

            this.ctx.fillStyle = gradient;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
            this.ctx.fill();

            this.ctx.restore();
        });
    }

    animate() {
        // Use GSAP ticker for consistent timing
        gsap.ticker.add(() => {
            this.update();
            this.draw();
        });
    }

    // Performance monitoring
    checkPerformance(fps) {
        if (fps < 30 && this.particles.length > 10) {
            // Reduce particle count if performance drops
            this.particles.pop();
        }
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('smoke-canvas')) {
        new SmokeBackground('smoke-canvas');
    }
});
