jQuery(document).ready(function ($) {
    'use strict';

    const AuthHandler = {

        // Initialize
        init() {
            this.bindEvents();
            this.setupPasswordToggles();
        },

        // Bind all events
        bindEvents() {
            // Login form submission
            $('#secure-login-form').on('submit', (e) => this.handleLogin(e));

            // Registration form submission
            $('#secure-register-form').on('submit', (e) => this.handleRegister(e));

            // Toggle between login/register
            $('[data-toggle]').on('click', (e) => this.handleToggle(e));
        },

        // Password show/hide toggle
        setupPasswordToggles() {
            $('.auth-password-toggle').on('click', function () {
                const $wrapper = $(this).closest('.auth-password-wrapper');
                const $input = $wrapper.find('input');
                const $eyeOpen = $(this).find('.eye-open');
                const $eyeClosed = $(this).find('.eye-closed');

                if ($input.attr('type') === 'password') {
                    $input.attr('type', 'text');
                    $eyeOpen.hide();
                    $eyeClosed.show();
                    $(this).attr('aria-label', 'Hide password');
                } else {
                    $input.attr('type', 'password');
                    $eyeOpen.show();
                    $eyeClosed.hide();
                    $(this).attr('aria-label', 'Show password');
                }
            });
        },

        // Toggle between forms
        handleToggle(e) {
            e.preventDefault();
            const target = $(e.currentTarget).data('toggle');

            this.clearErrors();

            if (target === 'register') {
                $('#login-section').hide();
                $('#register-section').show();
                $('#reg_username').focus();
            } else {
                $('#register-section').hide();
                $('#login-section').show();
                $('#login_username').focus();
            }
        },

        // Handle login submission
        handleLogin(e) {
            e.preventDefault();

            const $form = $(e.currentTarget);
            const $btn = $('#login-submit-btn');

            // Client-side validation
            const username = $('#login_username').val().trim();
            const password = $('#login_password').val();

            if (!username || !password) {
                this.showError('Please fill in all requiredfields.');
                return;
            }

            this.clearErrors();
            this.setButtonLoading($btn, true);

            // AJAX login
            $.ajax({
                type: 'POST',
                url: authParams.ajax_url,
                data: {
                    action: 'secure_customer_login',
                    username: username,
                    password: password,
                    rememberme: $('#rememberme').is(':checked'),
                    redirect_to: $form.find('[name="redirect_to"]').val(),
                    login_nonce: $form.find('[name="login_nonce"]').val()
                },
                timeout: 15000,
                success: (response) => {
                    if (response.success) {
                        this.showSuccess(response.data.message || 'Login successful! Redirecting...');

                        // Redirect after short delay
                        setTimeout(() => {
                            window.location.href = response.data.redirect;
                        }, 500);
                    } else {
                        this.setButtonLoading($btn, false);
                        this.showError(response.data.message || 'Invalid login credentials.');
                    }
                },
                error: (xhr, status) => {
                    this.setButtonLoading($btn, false);

                    if (status === 'timeout') {
                        this.showError('Request timed out. Please check your connection and try again.');
                    } else {
                        this.showError('An error occurred. Please try again.');
                    }

                    console.error('Login error:', xhr, status);
                }
            });
        },

        // Handle registration submission
        handleRegister(e) {
            e.preventDefault();

            const $form = $(e.currentTarget);
            const $btn = $('#register-submit-btn');

            // Client-side validation
            const username = $('#reg_username').val().trim();
            const email = $('#reg_email').val().trim();
            const mobile = $('#reg_mobile').val().trim();
            const password = $('#reg_password').val();

            if (!username || !email || !mobile || !password) {
                this.showError('Please fill in all required fields.');
                return;
            }

            // Email format validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                this.showError('Please enter a valid email address.');
                return;
            }

            // Mobile validation
            const mobileRegex = /^[0-9]{10}$/;
            if (!mobileRegex.test(mobile)) {
                this.showError('Please enter a valid 10-digit mobile number.');
                return;
            }

            this.clearErrors();
            this.setButtonLoading($btn, true);

            // AJAX registration
            $.ajax({
                type: 'POST',
                url: authParams.ajax_url,
                data: {
                    action: 'secure_customer_register',
                    username: username,
                    email: email,
                    mobile_number: mobile,
                    password: password,
                    register_nonce: $form.find('[name="register_nonce"]').val()
                },
                timeout: 15000,
                success: (response) => {
                    if (response.success) {
                        this.showSuccess(response.data.message || 'Account created! Redirecting...');

                        // Redirect after short delay
                        setTimeout(() => {
                            window.location.href = response.data.redirect || wc_add_to_cart_params.wc_ajax_url.replace('%%endpoint%%', 'myaccount');
                        }, 1000);
                    } else {
                        this.setButtonLoading($btn, false);
                        this.showError(response.data.message || 'Registration failed. Please try again.');
                    }
                },
                error: (xhr, status) => {
                    this.setButtonLoading($btn, false);

                    if (status === 'timeout') {
                        this.showError('Request timed out. Please check your connection and try again.');
                    } else {
                        this.showError('An error occurred. Please try again.');
                    }

                    console.error('Registration error:', xhr, status);
                }
            });
        },

        // Show error message
        showError(message) {
            const $container = $('#auth-error-container');
            $container
                .removeClass('auth-success')
                .addClass('auth-error')
                .html('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg><span>' + this.escapeHtml(message) + '</span>')
                .fadeIn(200);

            // Accessibility: Focus container for screen readers
            $container.attr('tabindex', '-1').focus();
        },

        // Show success message
        showSuccess(message) {
            const $container = $('#auth-error-container');
            $container
                .removeClass('auth-error')
                .addClass('auth-success')
                .html('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg><span>' + this.escapeHtml(message) + '</span>')
                .fadeIn(200);
        },

        // Clear errors
        clearErrors() {
            $('#auth-error-container').fadeOut(200);
        },

        // Set button loading state
        setButtonLoading($btn, loading) {
            if (loading) {
                $btn.prop('disabled', true).addClass('loading');
                $btn.find('.btn-text').hide();
                $btn.find('.btn-loading').show();
            } else {
                $btn.prop('disabled', false).removeClass('loading');
                $btn.find('.btn-text').show();
                $btn.find('.btn-loading').hide();
            }
        },

        // Escape HTML to prevent XSS
        escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        }
    };

    // Initialize when document is ready
    AuthHandler.init();
});
