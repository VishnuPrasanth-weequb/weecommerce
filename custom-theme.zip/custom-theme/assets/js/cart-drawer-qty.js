jQuery(document).ready(function ($) {
    /**
     * Cart Drawer Quantity Update
     * Handles +/- buttons in cart drawer
     */

    // Handle quantity increase/decrease
    $(document).on('click', '.cart-drawer .quantity-btn', function (e) {
        e.preventDefault();

        var $button = $(this);
        var $stepper = $button.closest('.quantity-stepper');
        var $quantityDisplay = $stepper.find('.quantity-input');
        var cart_item_key = $stepper.data('cart-item-key');
        var action = $button.data('action');
        var currentQty = parseInt($quantityDisplay.text());
        var newQty = currentQty;

        // Calculate new quantity
        if (action === 'increase') {
            newQty = currentQty + 1;
        } else if (action === 'decrease') {
            newQty = Math.max(0, currentQty - 1); // Don't go below 0
        }

        console.log('Updating cart item:', cart_item_key, 'from', currentQty, 'to', newQty);

        // Disable buttons during update
        $stepper.find('.quantity-btn').prop('disabled', true).css('opacity', '0.5');

        // Update cart via AJAX
        $.ajax({
            type: 'POST',
            url: wc_add_to_cart_params.ajax_url,
            data: {
                action: 'update_cart_item_quantity',
                cart_item_key: cart_item_key,
                quantity: newQty
            },
            success: function (response) {
                console.log('Cart update response:', response);

                if (response.success) {
                    // Update the display optimistically
                    $quantityDisplay.text(newQty);

                    // Trigger WooCommerce fragment refresh to update entire cart
                    $(document.body).trigger('wc_fragment_refresh');

                    console.log('Cart updated successfully');
                } else {
                    console.error('Failed to update cart:', response.data);
                    alert('Failed to update quantity. Please try again.');
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX error:', status, error);
                alert('Failed to update cart. Please try again.');
            },
            complete: function () {
                // Re-enable buttons
                $stepper.find('.quantity-btn').prop('disabled', false).css('opacity', '1');
            }
        });
    });

    // Listen for fragment refresh completion and update displays
    $(document.body).on('wc_fragments_refreshed', function () {
        console.log('Cart fragments refreshed');
    });
});
