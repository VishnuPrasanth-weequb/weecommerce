/**
 * Premium Product Gallery Interactions
 * Handles Thumbnail Switching, Lens Zoom, and Variation Sync.
 */

document.addEventListener('DOMContentLoaded', function () {
    initProductGallery();
});

function initProductGallery() {
    const gallery = document.querySelector('.pdp-image-gallery');
    if (!gallery) return;

    // Fade in gallery
    gallery.style.opacity = '1';

    const heroContainer = gallery.querySelector('.gallery-hero');
    const heroImageWrapper = heroContainer.querySelector('.woocommerce-product-gallery__image');
    let heroImg = heroImageWrapper ? heroImageWrapper.querySelector('img') : null; // Can be null if video
    const thumbs = gallery.querySelectorAll('.gallery-thumb-item');

    // 1. THUMBNAIL CLICK
    thumbs.forEach(thumb => {
        thumb.addEventListener('click', function (e) {
            e.preventDefault();

            // Remove active classes
            thumbs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');

            // Update Hero
            const newSrc = this.getAttribute('data-target-src');
            const newFull = this.getAttribute('data-target-full');

            if (heroImg && newSrc) {
                // If it's a video player currently, we might need to swap back to image?
                // For now assuming heroImg exists. If video replaced it, heroImg might be gone from DOM var reference?
                // Let's re-query to be safe.
                const currentHeroImg = heroContainer.querySelector('img.wp-post-image');

                if (currentHeroImg) {
                    currentHeroImg.src = newSrc;
                    currentHeroImg.srcset = ''; // Clear srcset to prevent interference
                    // Optional: Update data-large_image if zoom uses it
                    const parentLink = currentHeroImg.closest('a');
                    if (parentLink) parentLink.href = newFull;
                }
            }
        });
    });

    // 2. DESKTOP ZOOM (Simple Lens)
    if (window.matchMedia('(min-width: 1024px)').matches && heroContainer) {
        heroContainer.addEventListener('mousemove', function (e) {
            const img = heroContainer.querySelector('img.wp-post-image');
            if (!img) return; // No zoom on video

            const { left, top, width, height } = heroContainer.getBoundingClientRect();
            const x = (e.clientX - left) / width * 100;
            const y = (e.clientY - top) / height * 100;

            img.style.transformOrigin = `${x}% ${y}%`;
            img.style.transform = 'scale(1.5)'; // Zoom level
        });

        heroContainer.addEventListener('mouseleave', function () {
            const img = heroContainer.querySelector('img.wp-post-image');
            if (!img) return;

            img.style.transform = 'scale(1)';
            setTimeout(() => { img.style.transformOrigin = 'center center'; }, 300);
        });
    }

    // 3. VARIATION SYNC
    // WooCommerce triggers 'found_variation' on the form
    const form = document.querySelector('form.variations_form');
    if (form) {
        // jQuery is required for WC events usually
        if (typeof jQuery !== 'undefined') {
            jQuery(form).on('found_variation', function (event, variation) {
                if (variation.image && variation.image.src) {
                    // Update Hero Image
                    const img = heroContainer.querySelector('img.wp-post-image');
                    if (img) {
                        img.src = variation.image.src;
                        img.srcset = variation.image.srcset || '';
                    }
                    // Reset thumbs active state
                    thumbs.forEach(t => t.classList.remove('active'));
                }
            });

            jQuery(form).on('reset_image', function () {
                // Revert to first thumb (Main Image)
                const firstThumb = thumbs[0];
                if (firstThumb) {
                    firstThumb.click(); // Simulate click to restore
                }
            });
        }
    }
}
