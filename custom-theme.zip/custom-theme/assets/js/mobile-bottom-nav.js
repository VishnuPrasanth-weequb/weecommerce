/**
 * Mobile Bottom Navigation JavaScript
 * PWA Detection, Active States, Cart Count Sync
 * Production-Ready Implementation
 */

(function () {
    'use strict';

    // =========================================
    // PWA DETECTION
    // =========================================

    /**
     * Detect if app is running in PWA standalone mode
     */
    function isPWA() {
        // Check display-mode: standalone (Android/Desktop PWA)
        if (window.matchMedia('(display-mode: standalone)').matches) {
            return true;
        }

        // Check navigator.standalone (iOS)
        if (navigator.standalone === true) {
            return true;
        }

        // Check if launched from home screen (iOS fallback)
        if (window.navigator.standalone) {
            return true;
        }

        return false;
    }

    /**
     * Apply PWA body class for conditional styling
     */
    function markPWAMode() {
        if (isPWA()) {
            document.body.classList.add('is-pwa', 'is-standalone');
            console.log('PWA Mode: Detected standalone mode');
        }
    }

    // =========================================
    // ACTIVE STATE MANAGEMENT
    // =========================================

    /**
     * Update active state based on current URL
     */
    function updateActiveState() {
        const nav = document.querySelector('.mobile-bottom-nav');
        if (!nav) return;

        const navItems = nav.querySelectorAll('.nav-item');
        const currentPath = window.location.pathname;
        const currentUrl = window.location.href;

        // Remove all active classes first
        navItems.forEach(item => item.classList.remove('active'));

        // Determine which nav item should be active
        navItems.forEach(item => {
            const href = item.getAttribute('href');
            if (!href || href === '#') return;

            // Check if current URL matches nav item URL
            if (currentUrl === href || currentPath === new URL(href, window.location.origin).pathname) {
                item.classList.add('active');
            }
        });

        // Special handling for shop/product pages
        if (document.body.classList.contains('woocommerce-shop') ||
            document.body.classList.contains('single-product') ||
            document.body.classList.contains('tax-product_cat')) {
            const shopItem = nav.querySelector('[aria-label="Shop"]');
            if (shopItem) {
                navItems.forEach(item => item.classList.remove('active'));
                shopItem.classList.add('active');
            }
        }

        // Special handling for cart page
        if (document.body.classList.contains('woocommerce-cart')) {
            const cartItem = nav.querySelector('[aria-label="Cart"]');
            if (cartItem) {
                navItems.forEach(item => item.classList.remove('active'));
                cartItem.classList.add('active');
            }
        }

        // Special handling for account pages
        if (document.body.classList.contains('woocommerce-account') ||
            document.body.classList.contains('logged-in')) {
            const accountItem = nav.querySelector('[aria-label="Account"]');
            if (accountItem) {
                // Only activate if we're actually on account page
                if (currentPath.includes('/my-account') || currentPath.includes('/account')) {
                    navItems.forEach(item => item.classList.remove('active'));
                    accountItem.classList.add('active');
                }
            }
        }
    }

    // =========================================
    // CART COUNT SYNC
    // =========================================

    /**
     * Update cart badge count
     */
    function updateCartCount(count) {
        const badge = document.querySelector('.mobile-bottom-nav .cart-badge');
        if (!badge) return;

        // Update count
        badge.textContent = count;
        badge.setAttribute('data-count', count);

        // Show/hide badge based on count
        if (count > 0) {
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }

    /**
     * Listen to WooCommerce cart fragments update
     */
    function listenToCartUpdates() {
        // WooCommerce AJAX cart update event
        jQuery(document.body).on('wc_fragments_refreshed updated_cart_totals', function () {
            // Get updated cart count from WooCommerce
            const cartCountElement = document.querySelector('.cart-count, .cart-contents-count');
            if (cartCountElement) {
                const count = parseInt(cartCountElement.textContent) || 0;
                updateCartCount(count);
            }
        });

        // Listen to custom cart fragment updates
        jQuery(document.body).on('wc_fragments_loaded', function (event, data) {
            if (data && data.fragments) {
                // Look for cart count in fragments
                const cartFragment = data.fragments['.cart-count'] || data.fragments['span.cart-count'];
                if (cartFragment) {
                    const tempDiv = document.createElement('div');
                    tempDiv.innerHTML = cartFragment;
                    const count = parseInt(tempDiv.textContent) || 0;
                    updateCartCount(count);
                }
            }
        });

        // Fallback: Poll WooCommerce cart count every 2 seconds
        setInterval(function () {
            const cartCountElement = document.querySelector('.cart-count, .cart-contents-count');
            if (cartCountElement) {
                const count = parseInt(cartCountElement.textContent) || 0;
                updateCartCount(count);
            }
        }, 2000);
    }

    // =========================================
    // SEARCH FUNCTIONALITY
    // =========================================

    /**
     * Handle search button click
     */
    function setupSearchTrigger() {
        const searchTrigger = document.getElementById('mobile-search-trigger');
        if (!searchTrigger) return;

        searchTrigger.addEventListener('click', function (e) {
            e.preventDefault();

            // Try to find and focus on main search input
            const searchInput = document.querySelector('.search-field, input[type="search"], #s');
            if (searchInput) {
                searchInput.focus();
                searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                // If no search input found, redirect to shop page with search param
                if (mobileNavData && mobileNavData.shopUrl) {
                    window.location.href = mobileNavData.shopUrl;
                }
            }
        });
    }

    // =========================================
    // TOUCH FEEDBACK
    // =========================================

    /**
     * Add visual feedback on touch
     */
    function setupTouchFeedback() {
        const navItems = document.querySelectorAll('.mobile-bottom-nav .nav-item');

        navItems.forEach(item => {
            // Prevent 300ms tap delay on mobile
            item.addEventListener('touchstart', function () {
                this.style.backgroundColor = 'rgba(0, 0, 0, 0.05)';
            }, { passive: true });

            item.addEventListener('touchend', function () {
                const self = this;
                setTimeout(function () {
                    self.style.backgroundColor = '';
                }, 150);
            }, { passive: true });

            item.addEventListener('touchcancel', function () {
                this.style.backgroundColor = '';
            }, { passive: true });
        });
    }

    // =========================================
    // SCROLL BEHAVIOR (OPTIONAL)
    // =========================================

    /**
     * Hide nav on scroll down, show on scroll up
     * Disabled by default for better UX
     */
    function setupScrollBehavior() {
        let lastScrollTop = 0;
        let scrolling = false;
        const nav = document.querySelector('.mobile-bottom-nav');
        if (!nav) return;

        // Uncomment below to enable hide-on-scroll behavior
        /*
        window.addEventListener('scroll', function() {
            if (!scrolling) {
                window.requestAnimationFrame(function() {
                    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                    
                    if (scrollTop > lastScrollTop && scrollTop > 100) {
                        // Scrolling down
                        nav.classList.add('hidden');
                    } else {
                        // Scrolling up
                        nav.classList.remove('hidden');
                    }
                    
                    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
                    scrolling = false;
                });
                scrolling = true;
            }
        }, { passive: true });
        */
    }

    // =========================================
    // INITIALIZATION
    // =========================================

    /**
     * Initialize on DOM ready
     */
    function init() {
        // Check if navigation exists
        const nav = document.querySelector('.mobile-bottom-nav');
        if (!nav) {
            console.warn('Mobile bottom navigation not found');
            return;
        }

        // Detect and mark PWA mode
        markPWAMode();

        // Update active state
        updateActiveState();

        // Setup search trigger
        setupSearchTrigger();

        // Setup touch feedback
        setupTouchFeedback();

        // Setup scroll behavior (optional)
        setupScrollBehavior();

        // Add entrance animation
        setTimeout(function () {
            nav.classList.add('animate-in');
        }, 100);

        // Listen to cart updates (if WooCommerce is active)
        if (typeof jQuery !== 'undefined' && typeof wc_add_to_cart_params !== 'undefined') {
            listenToCartUpdates();
        }

        // Update active state on route change (for SPAs)
        window.addEventListener('popstate', updateActiveState);

        console.log('Mobile Bottom Navigation: Initialized');
    }

    // =========================================
    // DOCUMENT READY
    // =========================================

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
