document.addEventListener('DOMContentLoaded', function () {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const siteNavigation = document.querySelector('.site-navigation');

    if (mobileMenuToggle && siteNavigation) {
        mobileMenuToggle.addEventListener('click', function () {
            const isExpanded = mobileMenuToggle.getAttribute('aria-expanded') === 'true';
            mobileMenuToggle.setAttribute('aria-expanded', !isExpanded);

            // Simple toggle for now - in a real implementation we might want a slide animation
            if (siteNavigation.style.display === 'block') {
                siteNavigation.style.display = '';
            } else {
                siteNavigation.style.display = 'block';
                siteNavigation.style.position = 'absolute';
                siteNavigation.style.top = '100%';
                siteNavigation.style.left = '0';
                siteNavigation.style.width = '100%';
                siteNavigation.style.backgroundColor = 'var(--color-bg)';
                siteNavigation.style.padding = 'var(--spacing-md)';
                siteNavigation.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
                siteNavigation.style.borderTop = '1px solid var(--color-border)';
            }
        });
    }

    // Search Toggle (Placeholder for future functionality)
    const searchToggle = document.querySelector('.search-toggle');
    if (searchToggle) {
        searchToggle.addEventListener('click', function () {
            // console.log('Search toggled');
            // Future implementation: Open search modal or expand search bar
        });
    }

    // Sticky Header Scroll Effect (Optional: add class on scroll)
    const header = document.querySelector('.site-header');
    if (header) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 10) {
                header.classList.add('is-scrolled');
            } else {
                header.classList.remove('is-scrolled');
            }
        });
    }

    /* ===========================
       CART DRAWER
       =========================== */

    // Elements
    const cartDrawer = document.getElementById('cart-drawer');
    const cartOverlay = document.querySelector('.cart-overlay');
    const cartToggles = document.querySelectorAll('.cart-trigger, .cart-icon-wrapper');
    const cartClose = document.querySelector('.cart-drawer-close');

    // Functions
    function openCart() {
        if (cartDrawer && cartOverlay) {
            cartDrawer.classList.add('is-open');
            cartOverlay.classList.add('is-active');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }
    }

    function closeCart() {
        if (cartDrawer && cartOverlay) {
            cartDrawer.classList.remove('is-open');
            cartOverlay.classList.remove('is-active');
            document.body.style.overflow = '';
        }
    }

    // Event Listeners
    if (cartToggles) {
        cartToggles.forEach(toggle => {
            toggle.addEventListener('click', function (e) {
                e.preventDefault();
                openCart();
            });
        });
    }

    if (cartClose) {
        cartClose.addEventListener('click', closeCart);
    }

    if (cartOverlay) {
        cartOverlay.addEventListener('click', closeCart);
    }

    // Escape key to close
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeCart();
        }
    });

    // WooCommerce AJAX Hooks
    // Auto-open when item is added to cart
    // Using jQuery because WooCommerce depends on it for these triggers
    if (typeof jQuery !== 'undefined') {
        jQuery(document.body).on('added_to_cart', function () {
            // Cart fragments are already refreshed by the time this event fires
            // (handled in ajax-add-to-cart.js for single products)
            openCart();
        });

        // Ensure count updates correctly if not handled by fragments automatically (extra safety)
        jQuery(document.body).on('wc_cart_button_updated', function () {
            // Optional: Add bounce animation to cart icon
        });
    }

    /* ===========================
       SKELETON LOADERS
       =========================== */

    function initSkeletonLoaders() {
        // ... (Existing skeleton loader code remains if needed, likely handled separate or above)
        // Re-declaring or ensuring it doesn't conflict. 
        // For this edit, we are appending new logic.
    }

    /* ===========================
       OFFLINE CART & RELIABILITY
       =========================== */

    // Toast Utility
    function showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <span>${message}</span>
        `;

        container.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.add('is-visible');
        });

        // Remove after 3s
        setTimeout(() => {
            toast.classList.remove('is-visible');
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 3000);
    }

    // Offline Handling
    window.addEventListener('online', syncOfflineCart);
    window.addEventListener('offline', () => {
        showToast('You are offline. Changes will save locally.', 'warning');
    });

    // Intercept Add to Cart
    if (typeof jQuery !== 'undefined') {
        jQuery(document.body).on('click', '.add_to_cart_button', function (e) {
            if (!navigator.onLine) {
                e.preventDefault();
                const btn = jQuery(this);
                const productData = {
                    product_id: btn.data('product_id'),
                    quantity: btn.data('quantity') || 1,
                    variation_id: btn.data('variation_id') || 0
                };

                saveToOfflineCart(productData);

                // Visual Feedback
                btn.addClass('loading');
                setTimeout(() => {
                    btn.removeClass('loading').addClass('added');
                    showToast('Saved offline. Will sync when online.', 'info');
                }, 500);
            }
        });
    }

    function saveToOfflineCart(item) {
        let cart = JSON.parse(localStorage.getItem('weequb_offline_cart') || '[]');
        cart.push(item);
        localStorage.setItem('weequb_offline_cart', JSON.stringify(cart));
    }

    function syncOfflineCart() {
        const cart = JSON.parse(localStorage.getItem('weequb_offline_cart') || '[]');
        if (cart.length === 0) return;

        showToast('Back online! Syncing cart...', 'info');

        // Process sequentially to rely on WC AJAX
        let syncedCount = 0;

        function processNext() {
            if (syncedCount >= cart.length) {
                localStorage.removeItem('weequb_offline_cart');
                showToast(`Successfully synced ${syncedCount} items!`, 'success');
                // Trigger fragment refresh
                jQuery(document.body).trigger('wc_fragment_refresh');
                return;
            }

            const item = cart[syncedCount];

            // Simple AJAX posting to WC (simulated)
            // In a real scenario, we might hit ?wc-ajax=add_to_cart 
            // Here we just simulate success for the demo logic

            jQuery.post(
                woocommerce_params.wc_ajax_url.toString().replace('%%endpoint%%', 'add_to_cart'),
                item,
                function (response) {
                    if (response.error) {
                        console.error('Sync failed for item', item);
                    }
                    syncedCount++;
                    processNext();
                }
            ).fail(function () {
                console.error('Sync request failed');
                syncedCount++; // Skip on error to avoid loop
                processNext();
            });
        }

        if (typeof woocommerce_params !== 'undefined') {
            processNext();
        }
    }

    /* ===========================
       PUSH NOTIFICATIONS
       =========================== */
    const pushPrompt = document.getElementById('push-prompt');
    const allowBtn = document.getElementById('push-allow');
    const denyBtn = document.getElementById('push-deny');

    function showPushPrompt() {
        if (Notification.permission === 'default' && pushPrompt) {
            setTimeout(() => {
                pushPrompt.classList.add('is-visible');
            }, 5000); // Show after 5s
        }
    }

    if (allowBtn) {
        allowBtn.addEventListener('click', () => {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    showToast('Notifications enabled!', 'success');
                    // Here we would typically subscribeUserToPush()
                }
                pushPrompt.classList.remove('is-visible');
            });
        });
    }

    if (denyBtn) {
        denyBtn.addEventListener('click', () => {
            pushPrompt.classList.remove('is-visible');
        });
    }

    // Check permission on load
    if ('Notification' in window) {
        showPushPrompt();
    }

    /* ===========================
       CHECKOUT SAFEGUARDS
       =========================== */

    if (typeof jQuery !== 'undefined') {
        const checkoutForm = jQuery('form.checkout');

        checkoutForm.on('checkout_place_order', function () {
            const btn = jQuery('#place_order');

            // Prevent double click
            if (btn.hasClass('processing')) {
                return false;
            }

            btn.addClass('processing').prop('disabled', true);

            // Optional: Show loading spinner in button
            const originalText = btn.text();
            btn.data('original-text', originalText);
            btn.text('Processing...');

            return true;
        });

        // Reset if validation fails
        jQuery(document.body).on('checkout_error', function () {
            const btn = jQuery('#place_order');
            btn.removeClass('processing').prop('disabled', false);
            if (btn.data('original-text')) {
                btn.text(btn.data('original-text'));
            }
        });
    }
    /* ===========================
       CAROUSEL NAVIGATION
       =========================== */
    const carousels = document.querySelectorAll('.product-carousel-wrapper');

    carousels.forEach(wrapper => {
        const carousel = wrapper.querySelector('.product-carousel');
        const prevBtn = wrapper.querySelector('.carousel-arrow.prev');
        const nextBtn = wrapper.querySelector('.carousel-arrow.next');

        if (carousel && prevBtn && nextBtn) {
            // Scroll amount = card width (280) + gap (varies, assume 20ish)
            // We can calculate dynamically

            const getScrollAmount = () => {
                const card = carousel.querySelector('.product');
                return card ? card.offsetWidth + 20 : 300;
            };

            prevBtn.addEventListener('click', () => {
                carousel.scrollBy({ left: -(getScrollAmount()), behavior: 'smooth' });
            });

            nextBtn.addEventListener('click', () => {
                carousel.scrollBy({ left: getScrollAmount(), behavior: 'smooth' });
            });
        }
    });

});
