<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" href="<?php echo get_template_directory_uri(); ?>/assets/images/icon-192.png">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <div id="page" class="site">
        <a class="skip-link screen-reader-text"
            href="#content"><?php esc_html_e('Skip to content', 'custom-theme'); ?></a>

        <?php if (is_checkout()): ?>
            <!-- Minimal Checkout Header -->
            <header class="checkout-header">
                <div class="container">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="checkout-logo">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg"
                            alt="<?php bloginfo('name'); ?>" />
                    </a>
                </div>
            </header>
        <?php else: ?>
            <header id="masthead" class="premium-header">
                <div class="header-container">

                    <!-- Mobile Menu Toggle (First on Mobile) -->
                    <button class="mobile-menu-toggle" aria-label="Menu" aria-expanded="false">
                        <span class="menu-bar"></span>
                        <span class="menu-bar"></span>
                        <span class="menu-bar"></span>
                    </button>

                    <!-- Logo -->
                    <div class="header-logo">
                        <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.svg"
                                alt="<?php bloginfo('name'); ?>" class="site-logo-img" />
                        </a>
                    </div>

                    <!-- Navigation -->
                    <nav class="header-navigation" role="navigation"
                        aria-label="<?php esc_attr_e('Primary Navigation', 'custom-theme'); ?>">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'menu_class' => 'nav-menu',
                            'container' => false,
                            'fallback_cb' => function () {
                                echo '<ul class="nav-menu">';
                                echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';
                                echo '<li><a href="' . esc_url(home_url('/about-us')) . '">About Us</a></li>';
                                if (class_exists('WooCommerce')) {
                                    echo '<li><a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '">Products</a></li>';
                                }
                                echo '<li><a href="' . esc_url(home_url('/contact-us')) . '">Contact Us</a></li>';
                                echo '</ul>';
                            }
                        ));
                        ?>
                    </nav>

                    <!-- Header Actions -->
                    <div class="header-actions">

                        <!-- Wishlist -->
                        <a href="<?php echo esc_url(home_url('/wishlist')); ?>" class="header-action-btn"
                            aria-label="Wishlist">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/wishlist.svg" alt="Wishlist"
                                class="action-icon" />
                        </a>

                        <!-- Cart -->
                        <?php if (class_exists('WooCommerce')): ?>
                            <button class="header-action-btn cart-trigger" aria-label="Cart">
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/cart.svg" alt="Cart"
                                    class="action-icon" />
                                <?php
                                $cart_count = WC()->cart->get_cart_contents_count();
                                if ($cart_count > 0):
                                    ?>
                                    <span class="cart-badge"><?php echo esc_html($cart_count); ?></span>
                                <?php endif; ?>
                            </button>
                        <?php endif; ?>

                    </div>

                </div>
            </header>
        <?php endif; ?>

        <!-- Main content starts in individual templates (page.php, single.php, etc.) -->