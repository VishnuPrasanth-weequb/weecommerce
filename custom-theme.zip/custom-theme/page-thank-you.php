<?php
/**
 * Template Name: Thank You Page
 * Description: Order confirmation and thank you page for successful purchases
 */

get_header();
?>

<div class="thank-you-page">
    <div class="thank-you-container">
        <!-- Success Icon with Animation -->
        <div class="thank-you-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
            </svg>
        </div>

        <!-- Thank You Message -->
        <h1 class="thank-you-title">Thank You for Your Order!</h1>
        <p class="thank-you-subtitle">Your order has been successfully placed and is being processed.</p>

        <?php
        // Get order ID from URL parameter
        $order_id = isset($_GET['order_id']) ? absint($_GET['order_id']) : 0;

        if ($order_id && class_exists('WooCommerce')) {
            $order = wc_get_order($order_id);

            if ($order && $order->get_customer_id() === get_current_user_id()) {
                ?>
                <!-- Order Details Box -->
                <div class="order-confirmation-box">
                    <div class="order-confirmation-header">
                        <div class="order-info">
                            <span class="order-label">Order Number</span>
                            <span class="order-number">#
                                <?php echo $order->get_order_number(); ?>
                            </span>
                        </div>
                        <div class="order-info">
                            <span class="order-label">Order Date</span>
                            <span class="order-date">
                                <?php echo $order->get_date_created()->date_i18n('F j, Y'); ?>
                            </span>
                        </div>
                        <div class="order-info">
                            <span class="order-label">Total</span>
                            <span class="order-total">
                                <?php echo $order->get_formatted_order_total(); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Order Items -->
                    <div class="order-items">
                        <h3 class="order-items-title">Order Items</h3>
                        <div class="order-items-list">
                            <?php
                            foreach ($order->get_items() as $item_id => $item) {
                                $product = $item->get_product();
                                $product_image = $product ? wp_get_attachment_image_src(get_post_thumbnail_id($product->get_id()), 'thumbnail') : '';
                                ?>
                                <div class="order-item">
                                    <?php if ($product_image): ?>
                                        <img src="<?php echo esc_url($product_image[0]); ?>"
                                            alt="<?php echo esc_attr($item->get_name()); ?>" class="order-item-image">
                                    <?php endif; ?>
                                    <div class="order-item-details">
                                        <span class="order-item-name">
                                            <?php echo esc_html($item->get_name()); ?>
                                        </span>
                                        <span class="order-item-quantity">Qty:
                                            <?php echo $item->get_quantity(); ?>
                                        </span>
                                    </div>
                                    <span class="order-item-total">
                                        <?php echo $order->get_formatted_line_subtotal($item); ?>
                                    </span>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Shipping Address -->
                    <div class="order-address">
                        <h3 class="order-address-title">Shipping Address</h3>
                        <address class="order-address-content">
                            <?php echo $order->get_formatted_shipping_address(); ?>
                        </address>
                    </div>
                </div>

                <!-- Email Confirmation Notice -->
                <div class="email-notice">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                    <p>A confirmation email has been sent to <strong>
                            <?php echo esc_html($order->get_billing_email()); ?>
                        </strong></p>
                </div>
                <?php
            }
        }
        ?>

        <!-- Next Steps -->
        <div class="next-steps">
            <h2 class="next-steps-title">What's Next?</h2>
            <div class="next-steps-grid">
                <div class="next-step-card">
                    <div class="next-step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="1" y="3" width="15" height="13"></rect>
                            <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                            <circle cx="5.5" cy="18.5" r="2.5"></circle>
                            <circle cx="18.5" cy="18.5" r="2.5"></circle>
                        </svg>
                    </div>
                    <h3>Order Processing</h3>
                    <p>We're preparing your order for shipment. You'll receive tracking information soon.</p>
                </div>

                <div class="next-step-card">
                    <div class="next-step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                            <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                    </div>
                    <h3>Estimated Delivery</h3>
                    <p>Your order will arrive within 5-7 business days to your shipping address.</p>
                </div>

                <div class="next-step-card">
                    <div class="next-step-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                    </div>
                    <h3>Track Your Order</h3>
                    <p>Visit your account dashboard to track your order status and shipping updates.</p>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="thank-you-actions">
            <?php if ($order_id): ?>
                <a href="<?php echo esc_url(wc_get_account_endpoint_url('orders')); ?>" class="btn btn-primary">View Order
                    Details</a>
            <?php endif; ?>
            <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="btn btn-outline">Continue
                Shopping</a>
        </div>
    </div>
</div>

<!-- Confetti Canvas -->
<canvas id="confetti-canvas"></canvas>

<style>
    /* Thank You Page Styles */
    .thank-you-page {
        min-height: 70vh;
        padding: var(--space-2xl) var(--space-lg);
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        position: relative;
        overflow: hidden;
    }

    .thank-you-container {
        max-width: 900px;
        margin: 0 auto;
        text-align: center;
    }

    /* Success Icon */
    .thank-you-icon {
        width: 120px;
        height: 120px;
        margin: 0 auto var(--space-lg);
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: var(--radius-full);
        display: flex;
        align-items: center;
        justify-content: center;
        animation: scaleIn 0.5s ease-out;
        box-shadow: 0 10px 40px rgba(102, 126, 234, 0.4);
    }

    .thank-you-icon svg {
        color: white;
        animation: checkmark 0.8s ease-in-out 0.3s both;
    }

    @keyframes scaleIn {
        from {
            transform: scale(0);
            opacity: 0;
        }

        to {
            transform: scale(1);
            opacity: 1;
        }
    }

    @keyframes checkmark {
        0% {
            stroke-dasharray: 0, 100;
        }

        100% {
            stroke-dasharray: 100, 0;
        }
    }

    /* Typography */
    .thank-you-title {
        font-family: var(--font-heading);
        font-size: var(--text-h2);
        font-weight: var(--weight-bold);
        color: var(--color-text-dark);
        margin: 0 0 var(--space-sm);
        animation: fadeInUp 0.6s ease-out 0.2s both;
    }

    .thank-you-subtitle {
        font-size: var(--text-body);
        color: var(--color-text-muted);
        margin: 0 0 var(--space-xl);
        animation: fadeInUp 0.6s ease-out 0.4s both;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Order Confirmation Box */
    .order-confirmation-box {
        background: white;
        border-radius: var(--radius-lg);
        padding: var(--space-xl);
        margin: 0 0 var(--space-xl);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        text-align: left;
        animation: fadeInUp 0.6s ease-out 0.6s both;
    }

    .order-confirmation-header {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: var(--space-md);
        padding-bottom: var(--space-lg);
        border-bottom: 1px solid var(--color-border);
        margin-bottom: var(--space-lg);
    }

    .order-info {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .order-label {
        font-size: var(--text-small);
        color: var(--color-text-muted);
        text-transform: uppercase;
        letter-spacing: var(--tracking-wide);
    }

    .order-number,
    .order-date,
    .order-total {
        font-size: var(--text-body);
        font-weight: var(--weight-semibold);
        color: var(--color-text-dark);
    }

    .order-total {
        color: var(--color-primary);
        font-size: var(--text-h5);
    }

    /* Order Items */
    .order-items-title,
    .order-address-title {
        font-size: var(--text-h5);
        font-weight: var(--weight-semibold);
        margin: 0 0 var(--space-md);
        color: var(--color-text-dark);
    }

    .order-items-list {
        display: flex;
        flex-direction: column;
        gap: var(--space-md);
        margin-bottom: var(--space-lg);
    }

    .order-item {
        display: flex;
        align-items: center;
        gap: var(--space-md);
        padding: var(--space-md);
        background: var(--color-bg-light);
        border-radius: var(--radius-md);
    }

    .order-item-image {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: var(--radius-sm);
    }

    .order-item-details {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
    }

    .order-item-name {
        font-weight: var(--weight-medium);
        color: var(--color-text-dark);
    }

    .order-item-quantity {
        font-size: var(--text-small);
        color: var(--color-text-muted);
    }

    .order-item-total {
        font-weight: var(--weight-semibold);
        color: var(--color-text-dark);
    }

    /* Shipping Address */
    .order-address {
        padding-top: var(--space-lg);
        border-top: 1px solid var(--color-border);
    }

    .order-address-content {
        font-style: normal;
        line-height: var(--leading-relaxed);
        color: var(--color-text-dark);
    }

    /* Email Notice */
    .email-notice {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: var(--space-sm);
        padding: var(--space-md);
        background: #e8f5e9;
        border-radius: var(--radius-md);
        margin: 0 0 var(--space-2xl);
        animation: fadeInUp 0.6s ease-out 0.8s both;
    }

    .email-notice svg {
        color: #2e7d32;
        flex-shrink: 0;
    }

    .email-notice p {
        margin: 0;
        color: #1b5e20;
        font-size: var(--text-body-sm);
    }

    /* Next Steps */
    .next-steps {
        margin: 0 0 var(--space-2xl);
        animation: fadeInUp 0.6s ease-out 1s both;
    }

    .next-steps-title {
        font-family: var(--font-heading);
        font-size: var(--text-h3);
        font-weight: var(--weight-semibold);
        margin: 0 0 var(--space-xl);
        color: var(--color-text-dark);
    }

    .next-steps-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: var(--space-lg);
        text-align: left;
    }

    .next-step-card {
        background: white;
        padding: var(--space-lg);
        border-radius: var(--radius-lg);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        transition: var(--transition-base);
    }

    .next-step-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    .next-step-icon {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: var(--radius-md);
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: var(--space-md);
    }

    .next-step-icon svg {
        color: white;
    }

    .next-step-card h3 {
        font-size: var(--text-h5);
        font-weight: var(--weight-semibold);
        margin: 0 0 var(--space-sm);
        color: var(--color-text-dark);
    }

    .next-step-card p {
        font-size: var(--text-body-sm);
        line-height: var(--leading-relaxed);
        color: var(--color-text-muted);
        margin: 0;
    }

    /* Action Buttons */
    .thank-you-actions {
        display: flex;
        gap: var(--space-md);
        justify-content: center;
        flex-wrap: wrap;
        animation: fadeInUp 0.6s ease-out 1.2s both;
    }

    .btn {
        padding: var(--space-3) var(--space-xl);
        border-radius: var(--radius-md);
        font-weight: var(--weight-semibold);
        text-decoration: none;
        transition: var(--transition-base);
        display: inline-block;
    }

    .btn-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
    }

    .btn-outline {
        background: transparent;
        color: var(--color-text-dark);
        border: 2px solid var(--color-border);
    }

    .btn-outline:hover {
        background: var(--color-bg-light);
        border-color: var(--color-text-dark);
    }

    /* Confetti Canvas */
    #confetti-canvas {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 9999;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .thank-you-icon {
            width: 100px;
            height: 100px;
        }

        .thank-you-icon svg {
            width: 60px;
            height: 60px;
        }

        .thank-you-title {
            font-size: var(--text-h3);
        }

        .order-confirmation-header {
            grid-template-columns: 1fr;
        }

        .order-item {
            flex-wrap: wrap;
        }

        .next-steps-grid {
            grid-template-columns: 1fr;
        }

        .thank-you-actions {
            flex-direction: column;
        }

        .btn {
            width: 100%;
            text-align: center;
        }
    }
</style>

<script>
    // Confetti Animation
    document.addEventListener('DOMContentLoaded', function () {
        const canvas = document.getElementById('confetti-canvas');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const confetti = [];
        const confettiCount = 150;
        const gravity = 0.5;
        const terminalVelocity = 5;
        const drag = 0.075;
        const colors = [
            { front: '#667eea', back: '#764ba2' },
            { front: '#f093fb', back: '#f5576c' },
            { front: '#4facfe', back: '#00f2fe' },
            { front: '#43e97b', back: '#38f9d7' },
            { front: '#fa709a', back: '#fee140' }
        ];

        function randomRange(min, max) {
            return Math.random() * (max - min) + min;
        }

        function initConfetti() {
            for (let i = 0; i < confettiCount; i++) {
                confetti.push({
                    color: colors[Math.floor(randomRange(0, colors.length))],
                    dimensions: {
                        x: randomRange(10, 20),
                        y: randomRange(10, 30)
                    },
                    position: {
                        x: randomRange(0, canvas.width),
                        y: canvas.height - 1
                    },
                    rotation: randomRange(0, 2 * Math.PI),
                    scale: {
                        x: 1,
                        y: 1
                    },
                    velocity: {
                        x: randomRange(-25, 25),
                        y: randomRange(0, -50)
                    }
                });
            }
        }

        function render() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            confetti.forEach((confetto, index) => {
                let width = confetto.dimensions.x * confetto.scale.x;
                let height = confetto.dimensions.y * confetto.scale.y;

                ctx.translate(confetto.position.x, confetto.position.y);
                ctx.rotate(confetto.rotation);

                confetto.velocity.x -= confetto.velocity.x * drag;
                confetto.velocity.y = Math.min(confetto.velocity.y + gravity, terminalVelocity);
                confetto.velocity.x += Math.random() > 0.5 ? Math.random() : -Math.random();

                confetto.position.x += confetto.velocity.x;
                confetto.position.y += confetto.velocity.y;

                if (confetto.position.y >= canvas.height) confetti.splice(index, 1);

                if (confetto.position.x > canvas.width) confetto.position.x = 0;
                if (confetto.position.x < 0) confetto.position.x = canvas.width;

                confetto.scale.y = Math.cos(confetto.position.y * 0.1);
                ctx.fillStyle = confetto.scale.y > 0 ? confetto.color.front : confetto.color.back;

                ctx.fillRect(-width / 2, -height / 2, width, height);

                ctx.setTransform(1, 0, 0, 1, 0, 0);
            });

            if (confetti.length > 0) {
                window.requestAnimationFrame(render);
            }
        }

        initConfetti();
        render();

        window.addEventListener('resize', function () {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
    });
</script>

<?php get_footer(); ?>