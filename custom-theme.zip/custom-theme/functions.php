<?php
/**
 * Custom Theme Functions
 * 
 * @package Custom_Theme
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
require_once get_template_directory() . '/inc/product-video.php';

function custom_theme_setup()
{
    // Add theme support for title tag
    add_theme_support('title-tag');

    // Add theme support for post thumbnails
    add_theme_support('post-thumbnails');

    // Add theme support for HTML5 markup
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style'
    ));

    // Add theme support for custom logo
    add_theme_support('custom-logo', array(
        'height' => 100,
        'width' => 400,
        'flex-height' => true,
        'flex-width' => true,
    ));

    // Add theme support for WooCommerce
    add_theme_support('woocommerce');

    // Add WooCommerce gallery support
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'custom-theme'),
        'footer' => __('Footer Menu', 'custom-theme'),
    ));
}
add_action('after_setup_theme', 'custom_theme_setup');

// Include secure authentication handlers
require_once get_template_directory() . '/includes/secure-auth-handlers.php';

/**
 * Enqueue styles and scripts
 */
function custom_theme_scripts()
{
    // Global Design System (MUST load first to provide CSS custom properties)
    wp_enqueue_style('design-system', get_template_directory_uri() . '/assets/css/design-system.css', array(), '1.0.0');

    // Enqueue main stylesheet
    wp_enqueue_style('custom-theme-style', get_stylesheet_uri(), array('design-system'), '1.0.0');

    // Enqueue Premium Header Styles
    wp_enqueue_style('header-css', get_template_directory_uri() . '/assets/css/header.css', array(), '2.0.0');
    wp_enqueue_script('header-js', get_template_directory_uri() . '/assets/js/header.js', array('jquery'), '2.0.0', true);
    wp_enqueue_script('header-scroll-js', get_template_directory_uri() . '/assets/js/header-scroll.js', array(), '1.0.0', true);

    // Enqueue Mobile Menu Styles
    wp_enqueue_style('mobile-menu-css', get_template_directory_uri() . '/assets/css/mobile-menu.css', array(), '1.0.0');

    // Enqueue Premium Footer Styles (global)
    wp_enqueue_style('footer-css', get_template_directory_uri() . '/assets/css/footer.css', array('design-system'), '1.0.0');

    // Enqueue Cart Drawer Premium Styles
    wp_enqueue_style('cart-drawer-css', get_template_directory_uri() . '/assets/css/cart-drawer.css', array(), '1.0.0');

    // Enqueue Cart Drawer Quantity Edit JS
    wp_enqueue_script('cart-drawer-qty-js', get_template_directory_uri() . '/assets/js/cart-drawer-qty.js', array('jquery'), '1.0.0', true);

    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;900&family=Baskervville:wght@400&family=Cormorant+Garamond:wght@500&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap', array(), null);

    // Enqueue Roxborough CF font (if available locally)
    $roxborough_font = get_template_directory_uri() . '/assets/fonts/roxborough-cf.woff2';
    if (file_exists(get_template_directory() . '/assets/fonts/roxborough-cf.woff2')) {
        wp_enqueue_style('roxborough-font', get_template_directory_uri() . '/assets/fonts/roxborough-cf.css', array(), '1.0.0');
    }

    // Enqueue custom layout script
    wp_enqueue_script('custom-theme-layout', get_template_directory_uri() . '/assets/js/layout.js', array(), '1.0.0', true);

    // Page Builder Compatibility CSS (Elementor, Gutenberg, Classic Editor)
    wp_enqueue_style('page-builder-compat', get_template_directory_uri() . '/assets/css/page-builder-compat.css', array('design-system'), '1.0.0');

    // Contact Us Page CSS
    wp_enqueue_style('contact-page-css', get_template_directory_uri() . '/assets/css/contact-page.css', array('design-system'), '1.0.0');


    // Enqueue Single Product Premium Styles
    if (is_product()) {
        wp_enqueue_style('single-product-css', get_template_directory_uri() . '/assets/css/single-product.css', array(), '1.0.0');
        wp_enqueue_style('product-grid-fullwidth-css', get_template_directory_uri() . '/assets/css/product-grid-fullwidth.css', array(), '1.0.0');
        // AJAX Add to Cart for Single Products
        wp_enqueue_script('ajax-add-to-cart', get_template_directory_uri() . '/assets/js/ajax-add-to-cart.js', array('jquery'), '1.0.0', true);
        // Premium Gallery Interactions
        wp_enqueue_script('product-gallery-js', get_template_directory_uri() . '/assets/js/product-gallery.js', array('jquery'), '1.0.0', true);
    }

    // Enqueue Checkout Cart Editor (NEW)
    if (is_checkout()) {
        wp_enqueue_style('checkout-cart-editor-css', get_template_directory_uri() . '/assets/css/checkout-cart-editor.css', array(), '1.0.0');
        wp_enqueue_script('checkout-cart-editor-js', get_template_directory_uri() . '/assets/js/checkout-cart-editor.js', array('jquery'), '1.0.0', true);

        // Localize script with nonce
        wp_localize_script('checkout-cart-editor-js', 'checkoutEditorParams', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'update_cart_nonce' => wp_create_nonce('update_cart_item'),
        ));
    }

    // Enqueue Auth Page Styles & Scripts
    if (is_account_page() && !is_user_logged_in()) {
        wp_enqueue_style('auth-page-css', get_template_directory_uri() . '/assets/css/auth-page.css', array(), '2.0.0');
        wp_enqueue_script('secure-auth-js', get_template_directory_uri() . '/assets/js/secure-auth.js', array('jquery'), '2.0.0', true);

        // Localize script with AJAX URL
        wp_localize_script('secure-auth-js', 'authParams', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'login_nonce' => wp_create_nonce('secure_customer_login'),
            'register_nonce' => wp_create_nonce('secure_customer_register')
        ));
    }
}
add_action('wp_enqueue_scripts', 'custom_theme_scripts');

/**
 * PWA Integration - Inject Manifest and Meta Tags
 */
function custom_theme_pwa_head()
{
    echo '<link rel="manifest" href="/manifest.json">' . "\n";
    echo '<meta name="theme-color" content="#B57A3C">' . "\n";
    echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
    echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
    echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
    echo '<meta name="apple-mobile-web-app-title" content="Calmistry">' . "\n";
    echo '<link rel="apple-touch-icon" href="' . get_template_directory_uri() . '/assets/images/icon-192.png">' . "\n";
}
add_action('wp_head', 'custom_theme_pwa_head', 1);

/**
 * PWA Integration - Enqueue Service Worker Registration Script
 */
function custom_theme_pwa_scripts()
{
    wp_enqueue_script(
        'pwa-register',
        get_template_directory_uri() . '/assets/js/pwa-register.js',
        array(),
        '2.0.0',
        true // Load in footer
    );
}
add_action('wp_enqueue_scripts', 'custom_theme_pwa_scripts');


/**
 * Register widget areas
 */
function custom_theme_widgets_init()
{
    // Sidebar widget area
    register_sidebar(array(
        'name' => __('Sidebar', 'custom-theme'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here to appear in your sidebar.', 'custom-theme'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));

    // Footer widget area
    register_sidebar(array(
        'name' => __('Footer Widget Area', 'custom-theme'),
        'id' => 'footer-1',
        'description' => __('Add widgets here to appear in your footer.', 'custom-theme'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="footer-widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'custom_theme_widgets_init');

/**
 * Custom excerpt length
 */
function custom_theme_excerpt_length($length)
{
    return 20;
}
add_filter('excerpt_length', 'custom_theme_excerpt_length');

/**
 * Custom excerpt more text
 */
function custom_theme_excerpt_more($more)
{
    return '...';
}
add_filter('excerpt_more', 'custom_theme_excerpt_more');

/**
 * WooCommerce: Modify product columns
 */
function custom_theme_woocommerce_loop_columns()
{
    return 3;
}
add_filter('loop_shop_columns', 'custom_theme_woocommerce_loop_columns');

/**
 * WooCommerce: Products per page
 */
function custom_theme_woocommerce_products_per_page()
{
    return 12;
}
add_filter('loop_shop_per_page', 'custom_theme_woocommerce_products_per_page');

/**
 * Add custom body classes
 */
function custom_theme_body_classes($classes)
{
    // Add class if WooCommerce is active
    if (class_exists('WooCommerce')) {
        $classes[] = 'woocommerce-active';
    }

    return $classes;
}
add_filter('body_class', 'custom_theme_body_classes');

/**
 * WooCommerce Cart Fragments
 * Ensure cart contents update when products are added to the cart via AJAX
 */
function custom_theme_cart_fragments($fragments)
{
    ob_start();
    ?>
    <div class="widget_shopping_cart_content">
        <?php woocommerce_mini_cart(); ?>
    </div>
    <?php
    $fragments['div.widget_shopping_cart_content'] = ob_get_clean();

    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'custom_theme_cart_fragments');

/**
 * Update Cart Count AJAX
 */
function custom_theme_cart_count_fragments($fragments)
{
    ob_start();
    ?>
    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
    <?php
    $fragments['span.cart-count'] = ob_get_clean();

    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'custom_theme_cart_count_fragments');

/**
 * Add "Checkout Now" Button to Single Product Page
 * Uses a submit button to trigger native form processing (Variables supported).
 */
function custom_theme_buy_now_button()
{
    global $product;
    if (!$product->is_purchasable())
        return;

    // Output a Submit Button with a unique name
    echo '<button type="submit" name="weequb_checkout_now" value="1" class="buy_now_button">' . esc_html__('Checkout Now', 'custom-theme') . '</button>';
}
/* Note: Hook priority 31 puts it after Add to Cart button standard position (30) */
add_action('woocommerce_after_add_to_cart_button', 'custom_theme_buy_now_button', 31);

/**
 * Handle "Checkout Now" Redirect
 */
function custom_theme_checkout_redirect($url)
{
    // Only redirect if our specific button was clicked
    if (isset($_REQUEST['weequb_checkout_now']) && $_REQUEST['weequb_checkout_now'] == '1') {
        return wc_get_checkout_url();
    }
    return $url;
}
add_filter('woocommerce_add_to_cart_redirect', 'custom_theme_checkout_redirect');

/**
 * Disable WooCommerce "Added to cart" messages
 * Cart drawer provides sufficient visual feedback
 */
add_filter('wc_add_to_cart_message_html', '__return_empty_string');

/**
 * AJAX Add to Cart Handler for Single Product Pages
 */
add_action('wp_ajax_woocommerce_ajax_add_to_cart', 'custom_ajax_add_to_cart');
add_action('wp_ajax_nopriv_woocommerce_ajax_add_to_cart', 'custom_ajax_add_to_cart');

function custom_ajax_add_to_cart()
{
    $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
    $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
    $variation_id = absint($_POST['variation_id']);
    $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
    $product_status = get_post_status($product_id);

    if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id) && 'publish' === $product_status) {

        do_action('woocommerce_ajax_added_to_cart', $product_id);

        WC_AJAX::get_refreshed_fragments();
    } else {

        $data = array(
            'error' => true,
            'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
        );

        echo wp_send_json($data);
    }

    wp_die();
}

/**
 * AJAX Handler: Update Cart Item Quantity from Cart Drawer
 */
add_action('wp_ajax_update_cart_item_quantity', 'handle_cart_drawer_quantity_update');
add_action('wp_ajax_nopriv_update_cart_item_quantity', 'handle_cart_drawer_quantity_update');

function handle_cart_drawer_quantity_update()
{
    $cart_item_key = sanitize_text_field($_POST['cart_item_key']);
    $quantity = absint($_POST['quantity']);

    if (empty($cart_item_key)) {
        wp_send_json_error(array('message' => 'Invalid cart item'));
    }

    // If quantity is 0, remove the item
    if ($quantity === 0) {
        WC()->cart->remove_cart_item($cart_item_key);
    } else {
        WC()->cart->set_quantity($cart_item_key, $quantity, true);
    }

    WC()->cart->calculate_totals();

    wp_send_json_success(array(
        'message' => 'Cart updated',
        'cart_hash' => WC()->cart->get_cart_hash()
    ));
}

/**
 * STRICT PREMIUM PDP REFACTOR
 * Phase 2 & 4 Implementation
 */

// 1. Add Scoped Wrapper (.pdp-premium)
add_action('woocommerce_before_single_product', function () {
    echo '<div class="pdp-premium">';
}, 5); // Before everything else

add_action('woocommerce_after_single_product', function () {
    echo '</div><!-- .pdp-premium -->';
}, 50); // After everything else

// 2. Reorder Summary Panel Elements
add_action('init', function () {
    // Remove Default Actions
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
    remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50);

    // Add Actions with Strict Premium Ordering

    // 1. Title (Priority 5)
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);

    // 2. Short Description (Priority 10)
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 10);

    // 3. Price (Priority 15)
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 15);

    // 4. Ratings (Priority 20)
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 20);

    // 5. Add to Cart (Priority 30) - Form/Variations/Buttons
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);

    // 6. Meta (Priority 40) - SKU/Cats (Moved to bottom)
    add_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
});

/* =========================================================================
   CUSTOM WOOCOMMERCE PRODUCT LOOP HOOKS (Premium Card Layout)
   ========================================================================= */

// 1. Remove standard elements we don't need or want to re-position
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10); // Remove Add to Cart button

// 2. Add Short Description between Title and Price
add_action('woocommerce_after_shop_loop_item_title', 'custom_shop_product_short_description', 5);

function custom_shop_product_short_description()
{
    global $product;

    // Safety check to prevent 500 error if product global is missing
    if (!$product || !is_object($product)) {
        return;
    }

    $short_description = $product->get_short_description();

    if (!$short_description) {
        return;
    }
    ?>
    <div class="shop-product-short-description">
        <?php echo apply_filters('woocommerce_short_description', $short_description); ?>
    </div>
    <?php
}

// 3. Ensure Badge is minimal (we'll style it via CSS to be absolute top-right)
// Default WC hook 'woocommerce_show_product_loop_sale_flash' is at 'woocommerce_before_shop_loop_item_title' priority 10.
// We keep it there and just absolute position it.

// ========================================
// SHOP PAGINATION LIMIT
// ========================================
add_filter('loop_shop_per_page', 'custom_loop_shop_per_page', 20);
function custom_loop_shop_per_page($cols)
{
    return 9;
}

// Enqueue Filter Assets
add_action('wp_enqueue_scripts', 'shop_filters_enqueue', 20);
function shop_filters_enqueue()
{
    if (is_shop() || is_product_taxonomy()) {
        wp_enqueue_style('shop-filters', get_template_directory_uri() . '/assets/css/shop-filters.css', array(), '2.0.1');
        wp_enqueue_script('shop-filters', get_template_directory_uri() . '/assets/js/shop-filters.js', array('jquery'), '2.0.1', true);

        // Enqueue Premium Product Card Styles
        wp_enqueue_style('shop-products', get_template_directory_uri() . '/assets/css/shop-products.css', array(), '1.0.0');
    }
}

// AJAX Handler (FIXED: Proper Boolean validation)
add_action('wp_ajax_custom_filter_shop', 'handle_shop_filter_ajax');
add_action('wp_ajax_nopriv_custom_filter_shop', 'handle_shop_filter_ajax');

function handle_shop_filter_ajax()
{
    $filters = isset($_POST['filters']) ? $_POST['filters'] : array();
    $paged = isset($_POST['paged']) ? absint($_POST['paged']) : 1;

    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => 9, // Match the global setting
        'paged' => $paged,
    );

    // Initialize conditionally
    $tax_query = array();
    $meta_query = array();

    // SORT
    if (isset($filters['sort'])) {
        switch ($filters['sort']) {
            case 'price':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = '_price';
                $args['order'] = 'ASC';
                break;
            case 'price-desc':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = '_price';
                $args['order'] = 'DESC';
                break;
            case 'popularity':
                $args['meta_key'] = 'total_sales';
                $args['orderby'] = 'meta_value_num';
                break;
            case 'date':
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
                break;
            default:
                $args['orderby'] = 'menu_order title';
                break;
        }
    }

    // CATEGORIES
    if (!empty($filters['product_cat']) && is_array($filters['product_cat'])) {
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field' => 'slug',
            'terms' => $filters['product_cat'],
            'operator' => 'IN',
        );
    }

    // TAGS & DYNAMIC TAXONOMIES
    // Handle tags separately if passed
    if (!empty($filters['product_tag']) && is_array($filters['product_tag'])) {
        $tax_query[] = array(
            'taxonomy' => 'product_tag',
            'field' => 'slug',
            'terms' => $filters['product_tag'],
            'operator' => 'IN',
        );
    }

    // Iterate over other filters for dynamic taxonomies if valid
    // (This requires JS to pass them correctly, for now we stick to core filters + tags handling)

    // PRICE RANGE
    $min_price = !empty($filters['min_price']) ? floatval($filters['min_price']) : 0;
    $max_price = !empty($filters['max_price']) ? floatval($filters['max_price']) : 0;

    if ($max_price > 0) {
        $meta_query[] = array(
            'key' => '_price',
            'value' => array($min_price, $max_price),
            'compare' => 'BETWEEN',
            'type' => 'NUMERIC'
        );
    }

    // ON SALE (FIX: Proper boolean validation)
    // Only filter if explicitly true (not the string "false")
    $on_sale = false;
    if (isset($filters['on_sale'])) {
        // Handle both boolean and string values
        if (is_bool($filters['on_sale'])) {
            $on_sale = $filters['on_sale'];
        } elseif (is_string($filters['on_sale'])) {
            $on_sale = filter_var($filters['on_sale'], FILTER_VALIDATE_BOOLEAN);
        }
    }

    if ($on_sale === true) {
        $sale_ids = wc_get_product_ids_on_sale();
        if (!empty($sale_ids)) {
            $args['post__in'] = $sale_ids;
        } else {
            // No products on sale, return empty
            $args['post__in'] = array(0);
        }
    }

    // STOCK STATUS
    if (!empty($filters['stock_status']) && is_array($filters['stock_status'])) {
        $stock_status_options = $filters['stock_status'];
        // Mapping 'instock' to WC meta if needed, but normally 'stock_status' taxonomy or meta
        // WC 3.0+ uses '_stock_status' meta
        if (in_array('instock', $stock_status_options)) {
            $meta_query[] = array(
                'key' => '_stock_status',
                'value' => 'instock',
                'compare' => '='
            );
        }
    }

    // Add queries only if they have conditions
    if (count($tax_query) > 0) {
        if (count($tax_query) > 1)
            $tax_query['relation'] = 'AND';
        $args['tax_query'] = $tax_query;
    }

    if (count($meta_query) > 0) {
        if (count($meta_query) > 1)
            $meta_query['relation'] = 'AND';
        $args['meta_query'] = $meta_query;
    }

    // Execute Query
    $query = new WP_Query($args);

    ob_start();

    if ($query->have_posts()) {
        woocommerce_product_loop_start();

        while ($query->have_posts()) {
            $query->the_post();
            wc_get_template_part('content', 'product');
        }

        woocommerce_product_loop_end();
    } else {
        echo '<div class="no-products-found" style="text-align:center;padding:3rem 0;color:#6b7280;">';
        echo '<p style="font-size:1.1rem;margin-bottom:1rem;">No products found matching your criteria.</p>';
        echo '<p><a href="' . get_permalink(wc_get_page_id('shop')) . '" class="btn btn-primary">Clear Filters</a></p>';
        echo '</div>';
    }

    wp_reset_postdata();
    $html = ob_get_clean();

    wp_send_json_success(array(
        'html' => $html,
        'count' => $query->found_posts,
        'max_pages' => $query->max_num_pages,
        'paged' => $paged
    ));
}

// ========================================
// CHECKOUT CART EDITOR - AJAX HANDLERS
// ========================================

/**
 * Update Cart Item Quantity via AJAX
 */
add_action('wp_ajax_update_cart_item_qty', 'handle_update_cart_item_qty');
add_action('wp_ajax_nopriv_update_cart_item_qty', 'handle_update_cart_item_qty');

function handle_update_cart_item_qty()
{
    // Verify nonce
    check_ajax_referer('update_cart_item', 'security');

    $cart_item_key = isset($_POST['cart_item_key']) ? sanitize_text_field($_POST['cart_item_key']) : '';
    $quantity = isset($_POST['quantity']) ? absint($_POST['quantity']) : 0;

    if (empty($cart_item_key) || $quantity < 0) {
        wp_send_json_error(array('message' => 'Invalid parameters'));
    }

    // Update cart item quantity
    $updated = WC()->cart->set_quantity($cart_item_key, $quantity, true);

    if ($updated) {
        WC()->cart->calculate_totals();
        wp_send_json_success(array(
            'message' => 'Quantity updated',
            'cart_hash' => WC()->cart->get_cart_hash()
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to update quantity'));
    }
}

/**
 * Remove Cart Item via AJAX
 */
add_action('wp_ajax_remove_cart_item', 'handle_remove_cart_item');
add_action('wp_ajax_nopriv_remove_cart_item', 'handle_remove_cart_item');

function handle_remove_cart_item()
{
    // Verify nonce
    check_ajax_referer('update_cart_item', 'security');

    $cart_item_key = isset($_POST['cart_item_key']) ? sanitize_text_field($_POST['cart_item_key']) : '';

    if (empty($cart_item_key)) {
        wp_send_json_error(array('message' => 'Invalid cart item'));
    }

    // Remove item from cart
    $removed = WC()->cart->remove_cart_item($cart_item_key);

    if ($removed) {
        WC()->cart->calculate_totals();
        wp_send_json_success(array(
            'message' => 'Item removed',
            'cart_hash' => WC()->cart->get_cart_hash()
        ));
    } else {
        wp_send_json_error(array('message' => 'Failed to remove item'));
    }
}

/**
 * CUSTOM REGISTRATION FORM - Mobile Number Field
 */
add_action('woocommerce_register_form', 'custom_add_registration_fields');
function custom_add_registration_fields()
{
    ?>
    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="reg_mobile"><?php esc_html_e('Mobile Number', 'woocommerce'); ?> <span class="required">*</span></label>
        <input type="tel" class="woocommerce-Input woocommerce-Input--text input-text" name="mobile_number" id="reg_mobile"
            value="<?php echo esc_attr(isset($_POST['mobile_number']) ? $_POST['mobile_number'] : ''); ?>" required
            pattern="[0-9]{10}" />
    </p>
    <?php
}

/**
 * Validate Registration Fields
 */
add_filter('woocommerce_registration_errors', 'custom_validate_registration_fields', 10, 3);
function custom_validate_registration_fields($errors, $username, $email)
{
    // Validate mobile number
    if (empty($_POST['mobile_number'])) {
        $errors->add('mobile_number_error', __('Please enter your mobile number.', 'woocommerce'));
    } elseif (!preg_match('/^[0-9]{10}$/', $_POST['mobile_number'])) {
        $errors->add('mobile_number_error', __('Please enter a valid 10-digit mobile number.', 'woocommerce'));
    }

    return $errors;
}

/**
 * Save Custom Registration Fields
 */
add_action('woocommerce_created_customer', 'custom_save_registration_fields');
function custom_save_registration_fields($customer_id)
{
    if (isset($_POST['mobile_number'])) {
        update_user_meta($customer_id, 'billing_phone', sanitize_text_field($_POST['mobile_number']));
        update_user_meta($customer_id, 'mobile_number', sanitize_text_field($_POST['mobile_number']));
    }
}

// ========================================
// MOBILE BOTTOM NAVIGATION (PWA-STYLE)
// ========================================

/**
 * Inject Mobile Bottom Navigation Bar
 * Displays on mobile and PWA only
 */
function custom_theme_mobile_bottom_nav()
{
    // Don't show on checkout or order-received pages
    if (is_checkout() || is_order_received_page()) {
        return;
    }

    // Get cart count
    $cart_count = class_exists('WooCommerce') ? WC()->cart->get_cart_contents_count() : 0;

    // Determine active tab based on current page
    $current_url = home_url($_SERVER['REQUEST_URI']);
    $home_url = home_url('/');
    $shop_url = class_exists('WooCommerce') ? get_permalink(wc_get_page_id('shop')) : '';
    $cart_url = class_exists('WooCommerce') ? wc_get_cart_url() : '';
    $account_url = class_exists('WooCommerce') ? get_permalink(wc_get_page_id('myaccount')) : wp_login_url();

    // Determine active class
    $home_active = (is_front_page() || $current_url === $home_url) ? ' active' : '';
    $shop_active = (is_shop() || is_product_taxonomy() || is_product()) ? ' active' : '';
    $cart_active = (is_cart()) ? ' active' : '';
    $account_active = (is_account_page()) ? ' active' : '';

    ?>
    <!-- Mobile Bottom Navigation Bar -->
    <nav class="mobile-bottom-nav" role="navigation" aria-label="Mobile Navigation">
        <a href="<?php echo esc_url($home_url); ?>" class="nav-item<?php echo $home_active; ?>" aria-label="Home">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
            </svg>
            <span class="nav-label">Home</span>
        </a>

        <?php if (class_exists('WooCommerce')): ?>
            <a href="<?php echo esc_url($shop_url); ?>" class="nav-item<?php echo $shop_active; ?>" aria-label="Shop">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                </svg>
                <span class="nav-label">Shop</span>
            </a>
        <?php endif; ?>

        <button type="button" class="nav-item nav-search" aria-label="Search" id="mobile-search-trigger">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.35-4.35"></path>
            </svg>
            <span class="nav-label">Search</span>
        </button>

        <?php if (class_exists('WooCommerce')): ?>
            <a href="<?php echo esc_url($cart_url); ?>" class="nav-item<?php echo $cart_active; ?>" aria-label="Cart">
                <div class="nav-icon-wrapper">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                    </svg>
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-badge"
                            data-count="<?php echo esc_attr($cart_count); ?>"><?php echo esc_html($cart_count); ?></span>
                    <?php endif; ?>
                </div>
                <span class="nav-label">Cart</span>
            </a>
        <?php endif; ?>

        <a href="<?php echo esc_url($account_url); ?>" class="nav-item<?php echo $account_active; ?>" aria-label="Account">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
            </svg>
            <span class="nav-label"><?php echo is_user_logged_in() ? 'Account' : 'Login'; ?></span>
        </a>
    </nav>
    <?php
}
add_action('wp_footer', 'custom_theme_mobile_bottom_nav', 100);

/**
 * Enqueue Mobile Bottom Navigation Assets
 */
function custom_theme_mobile_bottom_nav_assets()
{
    // Enqueue CSS
    wp_enqueue_style(
        'mobile-bottom-nav',
        get_template_directory_uri() . '/assets/css/mobile-bottom-nav.css',
        array(),
        '1.0.0'
    );

    // Enqueue JS
    wp_enqueue_script(
        'mobile-bottom-nav',
        get_template_directory_uri() . '/assets/js/mobile-bottom-nav.js',
        array(),
        '1.0.0',
        true
    );

    // Localize script with data
    wp_localize_script('mobile-bottom-nav', 'mobileNavData', array(
        'homeUrl' => home_url('/'),
        'shopUrl' => class_exists('WooCommerce') ? get_permalink(wc_get_page_id('shop')) : '',
        'cartUrl' => class_exists('WooCommerce') ? wc_get_cart_url() : '',
        'accountUrl' => class_exists('WooCommerce') ? get_permalink(wc_get_page_id('myaccount')) : wp_login_url(),
        'cartCount' => class_exists('WooCommerce') ? WC()->cart->get_cart_contents_count() : 0,
    ));
}
add_action('wp_enqueue_scripts', 'custom_theme_mobile_bottom_nav_assets');

