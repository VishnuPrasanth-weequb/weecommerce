<?php
/**
 * Mini-cart
 *
 * @package WooCommerce\Templates
 * @version 7.9.0
 */

defined('ABSPATH') || exit;

do_action('woocommerce_before_mini_cart'); ?>

<?php if (!WC()->cart->is_empty()): ?>

    <div class="cart-list-header">
        <span>List of cart item</span>
        <span>
            <?php echo WC()->cart->get_cart_contents_count(); ?> items
        </span>
    </div>

    <ul class="woocommerce-mini-cart cart_list product_list_widget <?php echo esc_attr($args['list_class']); ?>">
        <?php
        do_action('woocommerce_before_mini_cart_contents');

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $_product = $cart_item['data'];
            $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);

            if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key)) {
                $product_name = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
                $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
                $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
                $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                ?>
                <li
                    class="woocommerce-mini-cart-item <?php echo esc_attr(apply_filters('woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key)); ?>">

                    <!-- 1. Image -->
                    <?php if (!empty($product_permalink)): ?>
                        <a href="<?php echo esc_url($product_permalink); ?>">
                            <?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </a>
                    <?php else: ?>
                        <?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                    <?php endif; ?>

                    <!-- 2. Details -->
                    <div class="cart-item-details">
                        <a href="<?php echo esc_url($product_permalink); ?>" class="cart-item-title">
                            <?php echo $product_name; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </a>

                        <?php echo wc_get_formatted_cart_item_data($cart_item); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

                        <div class="cart-item-price">
                            <?php echo $product_price; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                        </div>

                        <!-- Quantity Stepper with AJAX -->
                        <div class="quantity-stepper" style="margin-top: 8px; width: fit-content;"
                            data-cart-item-key="<?php echo esc_attr($cart_item_key); ?>">
                            <button type="button" class="quantity-btn minus" data-action="decrease">-</button>
                            <span class="quantity-input">
                                <?php echo esc_html($cart_item['quantity']); ?>
                            </span>
                            <button type="button" class="quantity-btn plus" data-action="increase">+</button>
                        </div>
                    </div>

                    <!-- 3. Actions -->
                    <div class="cart-item-actions">
                        <?php
                        echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            'woocommerce_cart_item_remove_link',
                            sprintf(
                                '<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></a>',
                                esc_url(wc_get_cart_remove_url($cart_item_key)),
                                esc_attr__('Remove this item', 'woocommerce'),
                                esc_attr($product_id),
                                esc_attr($cart_item_key),
                                esc_attr($_product->get_sku())
                            ),
                            $cart_item_key
                        );
                        ?>
                    </div>
                </li>
                <?php
            }
        }

        do_action('woocommerce_mini_cart_contents');
        ?>
    </ul>

    <!-- Summary Section -->
    <div class="cart-drawer-footer">
        <h4 style="margin-top: 0; margin-bottom: 16px;">Detail summary</h4>

        <div class="summary-row">
            <span>Subtotal (
                <?php echo WC()->cart->get_cart_contents_count(); ?> items)
            </span>
            <span>
                <?php echo WC()->cart->get_cart_subtotal(); ?>
            </span>
        </div>

        <div class="summary-row">
            <span>Shipping</span>
            <span>Calculated at checkout</span>
        </div>

        <?php if (WC()->cart->get_coupons()): ?>
            <?php foreach (WC()->cart->get_coupons() as $code => $coupon): ?>
                <div class="summary-row">
                    <span>Coupon:
                        <?php echo esc_html($code); ?>
                    </span>
                    <span class="discount-text">-
                        <?php echo wc_price($coupon->get_amount()); ?>
                    </span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <div class="summary-row total">
            <span>Total price</span>
            <span>
                <?php echo WC()->cart->get_total(); ?>
            </span>
        </div>

        <!-- Coupon Input (Visual) -->
        <div class="cart-coupon-row">
            <input type="text" class="cart-coupon-input" placeholder="Enter your promo code">
            <button class="cart-coupon-btn">Apply</button>
        </div>

        <div class="cart-buttons">
            <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="btn-view-cart">
                <?php esc_html_e('View cart', 'woocommerce'); ?>
            </a>
            <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="btn-checkout">
                <?php esc_html_e('Checkout', 'woocommerce'); ?>
            </a>
        </div>
    </div>

<?php else: ?>

    <p class="woocommerce-mini-cart__empty-message">
        <?php esc_html_e('No products in the cart.', 'woocommerce'); ?>
    </p>

<?php endif; ?>

<?php do_action('woocommerce_after_mini_cart'); ?>