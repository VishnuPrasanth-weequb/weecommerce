<?php
/**
 * Secure Customer Login & Registration
 * Hardened for 2026 standards
 * 
 * @package Custom_Theme
 * @version 2.0.0
 */

defined('ABSPATH') || exit;

// Redirect if already logged in
if (is_user_logged_in()) {
    wp_safe_redirect(wc_get_page_permalink('myaccount'));
    exit;
}

get_header();
?>

<div class="customer-login-premium">
    <div class="auth-page-container">

        <!-- Left Side: Hero -->
        <div class="auth-hero">
            <div class="auth-hero-overlay"></div>
            <div class="auth-hero-content">
                <h1>Make it simple, but<br>significant Shopping Experience</h1>
            </div>
        </div>

        <!-- Right Side: Secure Forms -->
        <div class="auth-forms">
            <div class="auth-forms-inner">

                <!-- Brand -->
                <div class="auth-brand">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                    <span><?php bloginfo('name'); ?></span>
                </div>

                <!-- Error Message Container -->
                <div id="auth-error-container" class="auth-error-container" style="display:none;" role="alert"
                    aria-live="assertive"></div>

                <!-- LOGIN FORM -->
                <div class="auth-form-section" id="login-section">
                    <h2 class="auth-heading">Login</h2>
                    <p class="auth-subheading">Login to your account</p>
                    <p class="auth-description">Welcome back! Please enter your credentials to continue.</p>

                    <form id="secure-login-form" class="auth-form" method="post" novalidate>

                        <div class="auth-form-row">
                            <label for="login_username">Email or Username <span class="required">*</span></label>
                            <input type="text" class="auth-input" name="username" id="login_username"
                                placeholder="Enter your email or username" autocomplete="username" required
                                aria-required="true" aria-describedby="username-desc" />
                            <span id="username-desc" class="auth-field-help" style="display:none;">Enter the email or
                                username you used when registering</span>
                        </div>

                        <div class="auth-form-row">
                            <label for="login_password">Password <span class="required">*</span></label>
                            <div class="auth-password-wrapper">
                                <input type="password" class="auth-input" name="password" id="login_password"
                                    placeholder="Enter your password" autocomplete="current-password" required
                                    aria-required="true" />
                                <button type="button" class="auth-password-toggle" aria-label="Show password"
                                    tabindex="-1">
                                    <svg class="eye-open" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                        <circle cx="12" cy="12" r="3"></circle>
                                    </svg>
                                    <svg class="eye-closed" style="display:none;" xmlns="http://www.w3.org/2000/svg"
                                        width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="2">
                                        <path
                                            d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24">
                                        </path>
                                        <line x1="1" y1="1" x2="23" y2="23"></line>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <div class="auth-form-extras">
                            <label class="auth-checkbox">
                                <input name="rememberme" type="checkbox" id="rememberme" value="forever" />
                                <span>Remember me</span>
                            </label>
                            <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" class="auth-link">Forgot
                                password?</a>
                        </div>

                        <?php wp_nonce_field('secure_customer_login', 'login_nonce'); ?>
                        <input type="hidden" name="action" value="secure_customer_login" />
                        <input type="hidden" name="redirect_to"
                            value="<?php echo esc_url(isset($_GET['redirect_to']) ? $_GET['redirect_to'] : wc_get_page_permalink('myaccount')); ?>" />

                        <button type="submit" class="auth-btn auth-btn-primary" id="login-submit-btn">
                            <span class="btn-text">Sign In</span>
                            <span class="btn-loading" style="display:none;">
                                <svg class="spinner" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
                                </svg>
                                Signing in...
                            </span>
                        </button>

                    </form>

                    <p class="auth-toggle">
                        Don't have an account yet?
                        <a href="#" class="auth-link-primary" data-toggle="register">Join <?php bloginfo('name'); ?></a>
                    </p>
                </div>

                <!-- REGISTRATION FORM -->
                <div class="auth-form-section" id="register-section" style="display: none;">
                    <h2 class="auth-heading">Create Account</h2>
                    <p class="auth-subheading">Join us today</p>
                    <p class="auth-description">Create an account to access exclusive deals and track your orders.</p>

                    <form id="secure-register-form" class="auth-form" method="post" novalidate>

                        <div class="auth-form-row">
                            <label for="reg_username">Username <span class="required">*</span></label>
                            <input type="text" class="auth-input" name="username" id="reg_username"
                                placeholder="Choose a username" required aria-required="true" />
                        </div>

                        <div class="auth-form-row">
                            <label for="reg_email">Email <span class="required">*</span></label>
                            <input type="email" class="auth-input" name="email" id="reg_email"
                                placeholder="your.email@example.com" autocomplete="email" required
                                aria-required="true" />
                        </div>

                        <div class="auth-form-row">
                            <label for="reg_mobile">Mobile Number <span class="required">*</span></label>
                            <input type="tel" class="auth-input" name="mobile_number" id="reg_mobile"
                                placeholder="10-digit number" pattern="[0-9]{10}" required aria-required="true" />
                        </div>

                        <div class="auth-form-row">
                            <label for="reg_password">Password <span class="required">*</span></label>
                            <div class="auth-password-wrapper">
                                <input type="password" class="auth-input" name="password" id="reg_password"
                                    placeholder="Create a strong password" autocomplete="new-password" required
                                    aria-required="true" />
                                <button type="button" class="auth-password-toggle" aria-label="Show password"
                                    tabindex="-1">
                                    <svg class="eye-open" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                        <circle cx="12" cy="12" r="3"></circle>
                                    </svg>
                                    <svg class="eye-closed" style="display:none;" xmlns="http://www.w3.org/2000/svg"
                                        width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="2">
                                        <path
                                            d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24">
                                        </path>
                                        <line x1="1" y1="1" x2="23" y2="23"></line>
                                    </svg>
                                </button>
                            </div>
                        </div>

                        <?php wp_nonce_field('secure_customer_register', 'register_nonce'); ?>
                        <input type="hidden" name="action" value="secure_customer_register" />

                        <button type="submit" class="auth-btn auth-btn-primary" id="register-submit-btn">
                            <span class="btn-text">Create Account</span>
                            <span class="btn-loading" style="display:none;">
                                <svg class="spinner" xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 12a9 9 0 1 1-6.219-8.56"></path>
                                </svg>
                                Creating account...
                            </span>
                        </button>

                    </form>

                    <p class="auth-toggle">
                        Already have an account?
                        <a href="#" class="auth-link-primary" data-toggle="login">Sign In</a>
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>

<?php
get_footer();
