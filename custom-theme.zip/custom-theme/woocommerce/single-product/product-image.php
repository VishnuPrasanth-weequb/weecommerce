<?php
/**
 * Custom Premium Product Image Gallery
 * Override for woocommerce/single-product/product-image.php
 */

defined('ABSPATH') || exit;

// Note: We don't use the standard 'woocommerce_before_single_product_summary' hook structure 
// because we are INSIDE the template called by that hook.

global $product;

$post_thumbnail_id = $product->get_image_id();
$attachment_ids = $product->get_gallery_image_ids();
$wrapper_classes = apply_filters('woocommerce_single_product_image_gallery_classes', array(
    'woocommerce-product-gallery',
    'pdp-image-gallery', // Our custom hook
    'images',
));
?>
<div class="<?php echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes))); ?>"
    style="opacity: 0; transition: opacity .25s ease-in-out;">

    <!-- HERO SECTION (Main Image / Video) -->
    <div class="gallery-hero">
        <?php
        if ($post_thumbnail_id) {
            $html = wc_get_gallery_image_html($post_thumbnail_id, true);
        } else {
            $html = '<div class="woocommerce-product-gallery__image--placeholder">';
            $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src('woocommerce_single')), esc_html__('Awaiting product image', 'woocommerce'));
            $html .= '</div>';
        }
        echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id);
        ?>
    </div>

    <!-- THUMBNAILS SECTION -->
    <div class="gallery-thumbs">
        <?php
        if ($attachment_ids && $product->get_image_id()) {
            // Include Main Image as first thumb? usually yes for "reset"
            // Get main image thumb URL
            $main_thumb_src = wp_get_attachment_image_url($post_thumbnail_id, 'thumbnail'); // WooCommerce default is 'thumbnail' or 'gallery_thumbnail'
            // We construct a simple thumb button for the main image
            echo '<div class="gallery-thumb-item active" data-target-src="' . esc_url(wp_get_attachment_image_url($post_thumbnail_id, 'woocommerce_single')) . '" data-target-full="' . esc_url(wp_get_attachment_image_url($post_thumbnail_id, 'full')) . '" data-attach-id="' . esc_attr($post_thumbnail_id) . '">';
            echo wp_get_attachment_image($post_thumbnail_id, 'thumbnail');
            echo '</div>';

            foreach ($attachment_ids as $attachment_id) {
                // Determine full and single srcs
                $full_src = wp_get_attachment_image_url($attachment_id, 'full');
                $single_src = wp_get_attachment_image_url($attachment_id, 'woocommerce_single');

                echo '<div class="gallery-thumb-item" data-target-src="' . esc_url($single_src) . '" data-target-full="' . esc_url($full_src) . '" data-attach-id="' . esc_attr($attachment_id) . '">';
                echo wp_get_attachment_image($attachment_id, 'thumbnail');
                echo '</div>';
            }
        }
        ?>
    </div>

</div>