<?php
/**
 * ============================================
 * SECURE AUTHENTICATION HANDLERS
 * WordPress/WooCommerce Customer Login System
 * Security-hardened for 2026 standards
 * ============================================
 */

/**
 * AJAX Login Handler
 * Implements secure authentication with generic error messages
 */
add_action('wp_ajax_nopriv_secure_customer_login', 'handle_secure_customer_login');
add_action('wp_ajax_secure_customer_login', 'handle_secure_customer_login');

function handle_secure_customer_login()
{
    // Rate limiting check (simple implementation)
    $ip = $_SERVER['REMOTE_ADDR'];
    $attempts_key = 'login_attempts_' . md5($ip);
    $attempts = get_transient($attempts_key) ?: 0;

    if ($attempts >= 5) {
        wp_send_json_error(array(
            'message' => 'Too many login attempts. Please try again later.'
        ));
    }

    // Verify nonce
    if (!isset($_POST['login_nonce']) || !wp_verify_nonce($_POST['login_nonce'], 'secure_customer_login')) {
        wp_send_json_error(array(
            'message' => 'Security verification failed. Please refresh and try again.'
        ));
    }

    // Sanitize inputs
    $username = isset($_POST['username']) ? trim(sanitize_text_field($_POST['username'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $remember = isset($_POST['rememberme']) && $_POST['rememberme'] === 'true';
    $redirect_to = isset($_POST['redirect_to']) ? esc_url_raw($_POST['redirect_to']) : wc_get_page_permalink('myaccount');

    // Validate inputs
    if (empty($username) || empty($password)) {
        set_transient($attempts_key, $attempts + 1, 900); // 15 minutes
        wp_send_json_error(array(
            'message' => 'Invalid login credentials.'
        ));
    }

    // Prepare credentials
    $credentials = array(
        'user_login' => $username,
        'user_password' => $password,
        'remember' => $remember
    );

    // Attempt authentication
    $user = wp_signon($credentials, is_ssl());

    // Handle errors with GENERIC message (security best practice)
    if (is_wp_error($user)) {
        set_transient($attempts_key, $attempts + 1, 900);

        // Log error for debugging (not shown to user)
        error_log('Login failed for user: ' . $username . ' - Error: ' . $user->get_error_message());

        // Generic error message (prevents user enumeration)
        wp_send_json_error(array(
            'message' => 'Invalid login credentials.'
        ));
    }

    // Success - clear attempts
    delete_transient($attempts_key);

    // Set auth cookie
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $remember);
    do_action('wp_login', $user->user_login, $user);

    wp_send_json_success(array(
        'message' => 'Login successful!',
        'redirect' => $redirect_to
    ));
}

/**
 * AJAX Registration Handler
 * Implements secure user registration
 */
add_action('wp_ajax_nopriv_secure_customer_register', 'handle_secure_customer_register');

function handle_secure_customer_register()
{
    // Verify nonce
    if (!isset($_POST['register_nonce']) || !wp_verify_nonce($_POST['register_nonce'], 'secure_customer_register')) {
        wp_send_json_error(array(
            'message' => 'Security verification failed. Please refresh and try again.'
        ));
    }

    // Sanitize inputs
    $username = isset($_POST['username']) ? sanitize_user($_POST['username']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $mobile = isset($_POST['mobile_number']) ? sanitize_text_field($_POST['mobile_number']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validate inputs
    $errors = new WP_Error();

    if (empty($username)) {
        $errors->add('username_required', 'Username is required.');
    } elseif (!validate_username($username)) {
        $errors->add('username_invalid', 'Username contains invalid characters.');
    } elseif (username_exists($username)) {
        $errors->add('username_exists', 'This username is already taken.');
    }

    if (empty($email)) {
        $errors->add('email_required', 'Email is required.');
    } elseif (!is_email($email)) {
        $errors->add('email_invalid', 'Please enter a valid email address.');
    } elseif (email_exists($email)) {
        $errors->add('email_exists', 'An account with this email already exists.');
    }

    if (empty($mobile)) {
        $errors->add('mobile_required', 'Mobile number is required.');
    } elseif (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $errors->add('mobile_invalid', 'Please enter a valid 10-digit mobile number.');
    }

    if (empty($password)) {
        $errors->add('password_required', 'Password is required.');
    } elseif (strlen($password) < 6) {
        $errors->add('password_weak', 'Password must be at least 6 characters long.');
    }

    // Return errors
    if ($errors->get_error_codes()) {
        wp_send_json_error(array(
            'message' => $errors->get_error_message()
        ));
    }

    // Create user
    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        wp_send_json_error(array(
            'message' => 'Registration failed. Please try again.'
        ));
    }

    // Save mobile number
    update_user_meta($user_id, 'billing_phone', $mobile);
    update_user_meta($user_id, 'mobile_number', $mobile);

    // Auto-login after registration
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id);
    do_action('woocommerce_created_customer', $user_id);

    wp_send_json_success(array(
        'message' => 'Account created successfully!',
        'redirect' => wc_get_page_permalink('myaccount')
    ));
}