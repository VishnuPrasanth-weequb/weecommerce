<?php
/**
 * The template for displaying all single posts
 *
 * @package Custom_Theme
 */

get_header();
?>

<main id="primary" class="site-main single-post-wrapper">
    <div class="container">
        <?php
        while (have_posts()):
            the_post();
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                <header class="entry-header">
                    <h1 class="entry-title">
                        <?php the_title(); ?>
                    </h1>

                    <div class="entry-meta">
                        <span class="posted-on">
                            <time datetime="<?php echo get_the_date('c'); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                        </span>
                        <span class="byline">
                            <?php esc_html_e('by', 'custom-theme'); ?>
                            <span class="author vcard">
                                <?php the_author(); ?>
                            </span>
                        </span>
                        <?php if (has_category()): ?>
                            <span class="cat-links">
                                <?php the_category(', '); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </header>

                <?php if (has_post_thumbnail()): ?>
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content">
                    <?php
                    the_content();

                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__('Pages:', 'custom-theme'),
                            'after' => '</div>',
                        )
                    );
                    ?>
                </div>

                <?php if (has_tag()): ?>
                    <footer class="entry-footer">
                        <div class="tags-links">
                            <?php the_tags('<span class="tags-label">' . esc_html__('Tags:', 'custom-theme') . '</span> ', ', '); ?>
                        </div>
                    </footer>
                <?php endif; ?>

            </article>

            <?php
            // Post navigation
            the_post_navigation(
                array(
                    'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'custom-theme') . '</span> <span class="nav-title">%title</span>',
                    'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'custom-theme') . '</span> <span class="nav-title">%title</span>',
                )
            );

            // Comments
            if (comments_open() || get_comments_number()):
                comments_template();
            endif;

        endwhile; // End of the loop
        ?>
    </div>
</main>

<?php
get_footer();
