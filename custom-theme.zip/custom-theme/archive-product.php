<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * @package Custom_Theme
 */

defined('ABSPATH') || exit;

get_header();

?>
<main id="primary" class="site-main shop-archive">
    <div class="container shop-page-container" style="padding-top: 20px;">

        <!-- PREMIUM FILTERS SECTION -->
        <div class="shop-filters-wrapper">
            <?php get_template_part('template-parts/shop-filters'); ?>
        </div>

        <!-- MAIN PRODUCT GRID -->
        <div class="shop-grid-wrapper" id="shop-results-container">
            <?php
            if (woocommerce_product_loop()) {

                // Remove default ordering/result count as we have our own in the filter bar
                remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);

                do_action('woocommerce_before_shop_loop');

                woocommerce_product_loop_start();

                if (wc_get_loop_prop('total')) {
                    while (have_posts()) {
                        the_post(); // Prime the post
            
                        // Hook into WC template part
                        // This ensures standard hooks fire
                        wc_get_template_part('content', 'product');
                    }
                }

                woocommerce_product_loop_end();

                do_action('woocommerce_after_shop_loop');

            } else {
                do_action('woocommerce_no_products_found');
            }
            ?>
        </div>

    </div>
</main>
<?php
get_footer();
