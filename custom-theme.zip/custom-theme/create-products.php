<?php
/**
 * Product Database Creation Script
 * Run once via WP-CLI or temporary page to create all 25 products
 * 
 * Usage: Place in theme root and access via browser ONCE, then delete
 */

// Security check
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/../../../');
    require_once(ABSPATH . 'wp-load.php');
}

if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
}

// Prevent duplicate runs
if (get_option('weequb_products_created')) {
    wp_die('Products already created. Delete option "weequb_products_created" to re-run.');
}

echo '<h1>Creating WeeQub Product Database...</h1>';
echo '<pre>';

// Product Data Structure
$products_data = array(
    // SHOES
    array(
        'name' => 'Minimalist Cloud Sneakers',
        'category' => 'Shoes',
        'price' => 89.00,
        'sale_price' => 69.00,
        'short_desc' => 'Ultra-light design meets premium comfort. Perfect for all-day wear.',
        'long_desc' => "<h3>Premium Craftsmanship</h3><p>Handcrafted with sustainable materials and modern design philosophy.</p><h3>All-Day Comfort</h3><p>Memory foam insole and breathable mesh upper ensure maximum comfort.</p><h3>Care Instructions</h3><p>Spot clean with damp cloth. Air dry only.</p>",
        'image' => 'shoe_minimalist_white_1',
    ),
    array(
        'name' => 'Executive Leather Loafers',
        'category' => 'Shoes',
        'price' => 149.00,
        'short_desc' => 'Timeless elegance in premium Italian leather. Dress to impress.',
        'long_desc' => "<h3>Genuine Leather</h3><p>100% full-grain Italian leather for lasting quality.</p><h3>Versatile Style</h3><p>Transition seamlessly from office to evening events.</p><h3>Fit & Sizing</h3><p>True to size. Break-in period: 2-3 wears.</p>",
        'image' => 'shoe_leather_loafer_1',
    ),
    array(
        'name' => 'Performance Running Shoes',
        'category' => 'Shoes',
        'price' => 119.00,
        'sale_price' => 99.00,
        'short_desc' => 'Engineered for speed and endurance. Your running partner.',
        'long_desc' => "<h3>Advanced Technology</h3><p>Responsive cushioning and energy return system.</p><h3>Breathable Design</h3><p>Engineered mesh for optimal airflow during intense workouts.</p><h3>Durability</h3><p>High-abrasion rubber outsole for 500+ miles.</p>",
        'image' => 'shoe_running_navy_1',
    ),
    array(
        'name' => 'Urban Canvas Slip-Ons',
        'category' => 'Shoes',
        'price' => 59.00,
        'short_desc' => 'Effortless style for modern living. Slip on and go.',
        'long_desc' => "<h3>Minimalist Design</h3><p>Clean lines and neutral tones for versatile styling.</p><h3>Comfort Features</h3><p>Cushioned footbed and flexible sole for natural movement.</p><h3>Sustainable Choice</h3><p>Made with organic cotton canvas.</p>",
        'image' => 'shoe_slipon_gray_1',
    ),
    array(
        'name' => 'Desert Suede Boots',
        'category' => 'Shoes',
        'price' => 139.00,
        'short_desc' => 'Classic desert boot reimagined. Your weekend essential.',
        'long_desc' => "<h3>Premium Suede</h3><p>Soft suede upper with Goodyear welt construction.</p><h3>Timeless Style</h3><p>A wardrobe staple that never goes out of fashion.</p><h3>Care Tips</h3><p>Use suede brush regularly. Apply protector spray before first wear.</p>",
        'image' => 'shoe_desert_boot_1',
    ),

    // T-SHIRTS
    array(
        'name' => 'Essential White Tee',
        'category' => 'T-Shirts',
        'price' => 29.00,
        'short_desc' => 'The perfect white t-shirt. Premium cotton, tailored fit.',
        'long_desc' => "<h3>Premium Fabric</h3><p>100% organic cotton with superior softness and durability.</p><h3>Perfect Fit</h3><p>Modern cut that flatters without clinging.</p><h3>Care</h3><p>Machine wash cold. Tumble dry low.</p>",
        'image' => 'tshirt_white_basic_1',
    ),
    array(
        'name' => 'Graphic Statement Tee',
        'category' => 'T-Shirts',
        'price' => 39.00,
        'sale_price' => 29.00,
        'short_desc' => 'Bold design, premium comfort. Express yourself.',
        'long_desc' => "<h3>Unique Design</h3><p>Exclusive artwork printed with eco-friendly inks.</p><h3>Oversized Fit</h3><p>Relaxed streetwear silhouette for modern style.</p><h3>Quality Guarantee</h3><p>Print won't fade or crack after wash.</p>",
        'image' => 'tshirt_black_graphic_1',
    ),
    array(
        'name' => 'Nautical Stripe Tee',
        'category' => 'T-Shirts',
        'price' => 35.00,
        'short_desc' => 'Classic stripes with a modern twist. Timeless casual wear.',
        'long_desc' => "<h3>Classic Design</h3><p>Navy stripes on premium cotton base.</p><h3>Versatile Styling</h3><p>Pairs well with jeans, chinos, or shorts.</p><h3>Fabric</h3><p>Soft-touch cotton jersey for all-day comfort.</p>",
        'image' => 'tshirt_navy_stripe_1',
    ),
    array(
        'name' => 'Organic Pocket Tee',
        'category' => 'T-Shirts',
        'price' => 32.00,
        'short_desc' => 'Sustainable style with a practical pocket. Earth-friendly fashion.',
        'long_desc' => "<h3>Eco-Conscious</h3><p>Made from 100% GOTS-certified organic cotton.</p><h3>Functional Detail</h3><p>Chest pocket adds utility and visual interest.</p><h3>Environmental Impact</h3><p>Carbon-neutral production and packaging.</p>",
        'image' => 'tshirt_olive_pocket_1',
    ),
    array(
        'name' => 'Henley Long Sleeve',
        'category' => 'T-Shirts',
        'price' => 45.00,
        'short_desc' => 'Elevated casual with button placket detail. Layer-friendly.',
        'long_desc' => "<h3>Premium Build</h3><p>Reinforced button placket and ribbed cuffs.</p><h3>Year-Round Versatility</h3><p>Perfect standalone or as a layering piece.</p><h3>Comfort Fabric</h3><p>Soft jersey blend with just the right weight.</p>",
        'image' => 'tshirt_gray_henley_1',
    ),

    // NIGHT PANTS
    array(
        'name' => 'Luxury Bamboo Sleep Pants',
        'category' => 'Night Pants',
        'price' => 49.00,
        'short_desc' => 'Silky-soft bamboo fabric. Sleep in sustainable luxury.',
        'long_desc' => "<h3>Bamboo Benefits</h3><p>Naturally breathable, moisture-wicking, and hypoallergenic.</p><h3>Premium Comfort</h3><p>Silky drape that feels amazing against skin.</p><h3>Sustainable Choice</h3><p>Bamboo grows rapidly without pesticides.</p>",
        'image' => 'pants_night_bamboo_1',
    ),
    array(
        'name' => 'Classic Flannel Pajama Pants',
        'category' => 'Night Pants',
        'price' => 39.00,
        'short_desc' => 'Cozy plaid flannel. Your winter sleep essential.',
        'long_desc' => "<h3>Soft Flannel</h3><p>Brushed cotton for maximum warmth and softness.</p><h3>Classic Pattern</h3><p>Timeless plaid design in navy and red.</p><h3>Relaxed Fit</h3><p>Elastic waistband with drawstring for perfect fit.</p>",
        'image' => 'pants_night_plaid_1',
    ),
    array(
        'name' => 'Charcoal Lounge Pants',
        'category' => 'Night Pants',
        'price' => 35.00,
        'short_desc' => 'Versatile loungewear. From bed to couch in comfort.',
        'long_desc' => "<h3>All-Day Comfort</h3><p>Soft cotton blend perfect for sleeping or relaxing.</p><h3>Modern Fit</h3><p>Tapered leg with cuffed ankle for contemporary look.</p><h3>Easy Care</h3><p>Machine washable. Gets softer with each wash.</p>",
        'image' => 'pants_night_charcoal_1',
    ),
    array(
        'name' => 'Summer Sleep Shorts',
        'category' => 'Night Pants',
        'price' => 25.00,
        'sale_price' => 19.00,
        'short_desc' => 'Lightweight and breathable. Perfect for warm nights.',
        'long_desc' => "<h3>Cool Comfort</h3><p>Breathable cotton for hot summer nights.</p><h3>Relaxed Fit</h3><p>Comfortable elastic waistband with drawcord.</p><h3>Versatile Use</h3><p>Great for sleep, exercise, or casual wear.</p>",
        'image' => 'pants_night_shorts_1',
    ),
    array(
        'name' => 'Jogger Sleep Pants',
        'category' => 'Night Pants',
        'price' => 42.00,
        'short_desc' => 'Athletic-inspired loungewear. Style meets comfort.',
        'long_desc' => "<h3>Modern Design</h3><p>Jogger silhouette with ribbed cuffs.</p><h3>Premium Fabric</h3><p>Soft cotton-poly blend for comfort and durability.</p><h3>Functional Pockets</h3><p>Side pockets for phone or essentials.</p>",
        'image' => 'pants_night_jogger_1',
    ),

    // LEGGINGS
    array(
        'name' => 'Performance Yoga Leggings',
        'category' => 'Leggings',
        'price' => 68.00,
        'short_desc' => 'Studio to street. High-performance activewear.',
        'long_desc' => "<h3>Technical Fabric</h3><p>4-way stretch with moisture-wicking technology.</p><h3>Squat-Proof</h3><p>Thick, opaque fabric provides full coverage.</p><h3>High Waist</h3><p>Supportive waistband that stays in place during workouts.</p>",
        'image' => 'leggings_black_yoga_1',
    ),
    array(
        'name' => 'Compression Training Leggings',
        'category' => 'Leggings',
        'price' => 75.00,
        'sale_price' => 59.00,
        'short_desc' => 'Compression support for intense workouts. Perform your best.',
        'long_desc' => "<h3>Graduated Compression</h3><p>Improves blood flow and reduces muscle fatigue.</p><h3>Mesh Panels</h3><p>Strategic ventilation for temperature regulation.</p><h3>Performance Ready</h3><p>Suitable for running, HIIT, or gym training.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Seamless Sculpt Leggings',
        'category' => 'Leggings',
        'price' => 72.00,
        'short_desc' => 'No seams, no distractions. Just smooth comfort.',
        'long_desc' => "<h3>Seamless Construction</h3><p>Eliminates chafing and creates sleek silhouette.</p><h3>Sculpting Technology</h3><p>Targeted compression zones for flattering fit.</p><h3>Buttery Soft</h3><p>Feels like second skin during any activity.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Pocket Power Leggings',
        'category' => 'Leggings',
        'price' => 65.00,
        'short_desc' => 'Functional pockets meet premium performance. Keep essentials close.',
        'long_desc' => "<h3>Side Pockets</h3><p>Large enough for phone, keys, and cards.</p><h3>High-Rise Fit</h3><p>Provides core support and stays secure.</p><h3>All-Purpose</h3><p>Perfect for gym, errands, or casual wear.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Print Pattern Leggings',
        'category' => 'Leggings',
        'price' => 58.00,
        'short_desc' => 'Bold patterns, premium performance. Stand out in style.',
        'long_desc' => "<h3>Exclusive Print</h3><p>Unique design that won't fade or crack.</p><h3>Moisture Management</h3><p>Quick-dry fabric keeps you comfortable.</p><h3>Versatile Style</h3><p>Pairs well with any top for gym or street.</p>",
        'image' => 'placeholder',
    ),

    // SAREES (Using placeholder - will add AI images later)
    array(
        'name' => 'Royal Red Silk Saree',
        'category' => 'Sarees',
        'price' => 189.00,
        'sale_price' => 149.00,
        'short_desc' => 'Luxurious silk with traditional elegance. Perfect for celebrations.',
        'long_desc' => "<h3>Pure Silk</h3><p>Handwoven silk with lustrous finish and rich drape.</p><h3>Golden Border</h3><p>Traditional zari work adds ceremonial elegance.</p><h3>Occasion</h3><p>Ideal for weddings, festivals, and formal events.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Navy Cotton Saree',
        'category' => 'Sarees',
        'price' => 79.00,
        'short_desc' => 'Breathable elegance for everyday wear. Comfortable and beautiful.',
        'long_desc' => "<h3>Premium Cotton</h3><p>Soft, breathable fabric perfect for all-day wear.</p><h3>Silver Embroidery</h3><p>Delicate threadwork adds subtle sophistication.</p><h3>Easy Care</h3><p>Machine washable for practical daily use.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Mint Chiffon Saree',
        'category' => 'Sarees',
        'price' => 99.00,
        'short_desc' => 'Lightweight luxury in pastel perfection. Effortlessly graceful.',
        'long_desc' => "<h3>Flowy Chiffon</h3><p>Lightweight fabric with beautiful drape and movement.</p><h3>Delicate Border</h3><p>Subtle embellishment in complementary tones.</p><h3>Summer Ready</h3><p>Cool and comfortable for warm weather events.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Purple Banarasi Saree',
        'category' => 'Sarees',
        'price' => 249.00,
        'short_desc' => 'Heritage craftsmanship in royal purple. A timeless treasure.',
        'long_desc' => "<h3>Banarasi Tradition</h3><p>Authentic weaving technique from Varanasi artisans.</p><h3>Gold Threadwork</h3><p>Intricate zari patterns showcase masterful craftsmanship.</p><h3>Investment Piece</h3><p>Heirloom quality that lasts generations.</p>",
        'image' => 'placeholder',
    ),
    array(
        'name' => 'Ivory Linen Saree',
        'category' => 'Sarees',
        'price' => 89.00,
        'short_desc' => 'Modern minimalism meets traditional elegance. Understated beauty.',
        'long_desc' => "<h3>Natural Linen</h3><p>Breathable eco-friendly fabric with natural texture.</p><h3>Minimalist Design</h3><p>Clean lines and simple border for contemporary aesthetic.</p><h3>Sustainable Fashion</h3><p>Made from organic linen with low environmental impact.</p>",
        'image' => 'placeholder',
    ),
);

// Create categories first
$categories = array('Shoes', 'T-Shirts', 'Night Pants', 'Leggings', 'Sarees');
foreach ($categories as $cat) {
    if (!term_exists($cat, 'product_cat')) {
        wp_insert_term($cat, 'product_cat');
        echo "✓ Created category: $cat\n";
    }
}

// Create products
foreach ($products_data as $index => $product_data) {
    $product = new WC_Product_Simple();

    $product->set_name($product_data['name']);
    $product->set_status('publish');
    $product->set_catalog_visibility('visible');
    $product->set_regular_price($product_data['price']);

    if (isset($product_data['sale_price'])) {
        $product->set_sale_price($product_data['sale_price']);
    }

    $product->set_short_description($product_data['short_desc']);
    $product->set_description($product_data['long_desc']);

    // Set category
    $term = get_term_by('name', $product_data['category'], 'product_cat');
    if ($term) {
        $product->set_category_ids(array($term->term_id));
    }

    $product->set_manage_stock(false);
    $product->set_stock_status('instock');

    $product_id = $product->save();

    echo "✓ Created: {$product_data['name']} (ID: $product_id)\n";
}

// Mark as completed
update_option('weequb_products_created', true);

echo "\n✅ All products created successfully!\n";
echo "Total: 25 products across 5 categories\n\n";
echo "⚠️ Note: Some products use placeholder images. Run image upload script next.\n";
echo "</pre>";
