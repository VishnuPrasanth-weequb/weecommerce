<?php
/**
 * Front Page Template
 * 
 * @package Custom_Theme
 */

get_header();
?>

<main id="primary" class="site-main front-page">
    <?php
    while (have_posts()):
        the_post();

        // Output page content
        the_content();

    endwhile;
    ?>
</main>

<?php
get_footer();
