<?php
/**
 * Shop Filters Template Part
 * 
 * Contains:
 * - Search Bar
 * - Sort Dropdown
 * - Filter Buttons (Desktop) / Trigger (Mobile)
 * - Active Chips
 */

$total_results = wc_get_loop_prop('total');
?>
<div class="shop-filters-premium" id="premium-filters">

    <!-- TOP BAR: New Arrival + Product Count + Chips -->
    <div class="filters-top-bar">

        <!-- Mobile Trigger -->
        <button class="btn-filter-toggle mobile-only" id="mobile-filter-trigger">
            <span class="icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M4 21v-7" />
                    <path d="M4 10V3" />
                    <path d="M12 21v-9" />
                    <path d="M12 8V3" />
                    <path d="M20 21v-5" />
                    <path d="M20 12V3" />
                    <path d="M1 14h6" />
                    <path d="M9 8h6" />
                    <path d="M17 16h6" />
                </svg>
            </span>
            <span class="text">
                <?php esc_html_e('Filter', 'custom-theme'); ?>
            </span>
        </button>

        <!-- Result Count -->
        <div class="filter-result-wrapper">
            <span class="result-count">
                <strong id="filter-result-count">
                    <?php echo esc_html($total_results); ?>
                </strong>
                <?php esc_html_e('Products', 'custom-theme'); ?>
            </span>
        </div>

        <!-- Sort Dropdown -->
        <div class="filters-sort">
            <select name="sort" id="shop-sort-select" class="premium-select">
                <option value="menu_order">
                    <?php esc_html_e('Default Sorting', 'custom-theme'); ?>
                </option>
                <option value="popularity">
                    <?php esc_html_e('Best Sellers', 'custom-theme'); ?>
                </option>
                <option value="date">
                    <?php esc_html_e('Newest Arrivals', 'custom-theme'); ?>
                </option>
                <option value="price">
                    <?php esc_html_e('Price: Low to High', 'custom-theme'); ?>
                </option>
                <option value="price-desc">
                    <?php esc_html_e('Price: High to Low', 'custom-theme'); ?>
                </option>
            </select>
        </div>
    </div>

    <!-- Active Filter Chips Row -->
    <div class="active-filter-chips-row" id="active-filter-chips">
        <!-- Javascript will populate chips here -->
    </div>

    <!-- FILTER COLLAPSIBLE AREA (Desktop Horizontal / Mobile Drawer) -->
    <div class="filters-panel" id="filters-panel">

        <div class="filters-panel-header mobile-only">
            <h3>
                <?php esc_html_e('Filters', 'custom-theme'); ?>
            </h3>
            <button class="btn-close-filters" id="close-filters">×</button>
        </div>

        <div class="filters-grid">

            <!-- Category Filter -->
            <div class="filter-group filter-accordion">
                <h4 class="filter-accordion-header" data-filter="category">
                    <span><?php esc_html_e('Category', 'custom-theme'); ?></span>
                    <svg class="accordion-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </h4>
                <div class="filter-options filter-accordion-content" data-filter="category">
                    <?php
                    // Get all parent categories (no parent)
                    $parent_categories = get_terms([
                        'taxonomy' => 'product_cat',
                        'hide_empty' => true,
                        'parent' => 0
                    ]);

                    foreach ($parent_categories as $parent_cat) {
                        // Display parent category
                        echo '<label class="checkbox-item parent-category">';
                        echo '<input type="checkbox" name="product_cat" value="' . esc_attr($parent_cat->slug) . '"> ';
                        echo '<span class="label-text">' . esc_html($parent_cat->name) . ' <span class="count">(' . esc_html($parent_cat->count) . ')</span></span>';
                        echo '</label>';

                        // Get child categories
                        $child_categories = get_terms([
                            'taxonomy' => 'product_cat',
                            'hide_empty' => true,
                            'parent' => $parent_cat->term_id
                        ]);

                        // Display child categories with indentation
                        if (!empty($child_categories) && !is_wp_error($child_categories)) {
                            foreach ($child_categories as $child_cat) {
                                echo '<label class="checkbox-item child-category">';
                                echo '<input type="checkbox" name="product_cat" value="' . esc_attr($child_cat->slug) . '"> ';
                                echo '<span class="label-text">' . esc_html($child_cat->name) . ' <span class="count">(' . esc_html($child_cat->count) . ')</span></span>';
                                echo '</label>';
                            }
                        }
                    }
                    ?>
                </div>
            </div>

            <!-- Price Filter -->
            <div class="filter-group filter-accordion">
                <h4 class="filter-accordion-header" data-filter="price">
                    <span><?php esc_html_e('Price', 'custom-theme'); ?></span>
                    <svg class="accordion-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </h4>
                <div class="filter-accordion-content" data-filter="price">
                    <div class="price-range-inputs">
                        <input type="number" name="min_price" placeholder="Min" class="price-input" min="0">
                        <span class="separator">-</span>
                        <input type="number" name="max_price" placeholder="Max" class="price-input" min="0">
                        <button class="btn-apply-price" id="apply-price-btn">→</button>
                    </div>
                </div>
            </div>

            <!-- Stock Status -->
            <div class="filter-group filter-accordion">
                <h4 class="filter-accordion-header" data-filter="availability">
                    <span><?php esc_html_e('Availability', 'custom-theme'); ?></span>
                    <svg class="accordion-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </h4>
                <div class="filter-options filter-accordion-content" data-filter="availability">
                    <label class="checkbox-item">
                        <input type="checkbox" name="stock_status" value="instock">
                        <span class="label-text">
                            <?php esc_html_e('In Stock', 'custom-theme'); ?>
                        </span>
                    </label>
                    <label class="checkbox-item">
                        <input type="checkbox" name="on_sale" value="true">
                        <span class="label-text">
                            <?php esc_html_e('On Sale', 'custom-theme'); ?>
                        </span>
                    </label>
                </div>
            </div>

            <!-- DYNAMIC FILTERS: Attributes, Tags, Custom Taxonomies -->
            <?php
            // 1. Get all registered taxonomies for products
            $all_taxonomies = get_object_taxonomies('product', 'objects');

            // 2. Define exclusions (System, Internal, or Manually Handled)
            $exclude_taxonomies = [
                'product_cat',             // Handled specifically above (Hierarchy)
                'product_type',            // Internal WC
                'product_visibility',      // Internal WC
                'product_shipping_class',  // Internal WC
                'translation_priority',    // Internal WP
            ];

            // 3. Loop through taxonomies
            foreach ($all_taxonomies as $taxonomy_slug => $taxonomy_obj) {

                // Skip if excluded or not public
                if (in_array($taxonomy_slug, $exclude_taxonomies) || !$taxonomy_obj->public) {
                    continue;
                }

                // Get terms for this taxonomy
                $terms = get_terms([
                    'taxonomy' => $taxonomy_slug,
                    'hide_empty' => true, // Only show used terms
                ]);

                // Skip if no terms found
                if (empty($terms) || is_wp_error($terms)) {
                    continue;
                }

                $label = $taxonomy_obj->label; // e.g. "Color", "Size", "Tags"
                ?>

                <!-- Dynamic Accordion: <?php echo esc_html($label); ?> -->
                <div class="filter-group filter-accordion">
                    <h4 class="filter-accordion-header" data-filter="<?php echo esc_attr($taxonomy_slug); ?>">
                        <span><?php echo esc_html($label); ?></span>
                        <svg class="accordion-icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2">
                            <polyline points="6 9 12 15 18 9"></polyline>
                        </svg>
                    </h4>
                    <div class="filter-options filter-accordion-content"
                        data-filter="<?php echo esc_attr($taxonomy_slug); ?>">
                        <?php
                        foreach ($terms as $term) {
                            $is_child = ($term->parent != 0); // Check if term is a child (if hierarchical)
                            $child_class = $is_child ? 'child-category' : ''; // Use existing styles if hierarchical
                            // Note: Attributes are usually flat, but this supports hierarchy if enabled
                    
                            echo '<label class="checkbox-item ' . esc_attr($child_class) . '">';
                            echo '<input type="checkbox" name="' . esc_attr($taxonomy_slug) . '" value="' . esc_attr($term->slug) . '"> ';
                            echo '<span class="label-text">' . esc_html($term->name) . ' <span class="count">(' . esc_html($term->count) . ')</span></span>';
                            echo '</label>';
                        }
                        ?>
                    </div>
                </div>

                <?php
            }
            ?>

        </div>

        <div class="filters-panel-footer mobile-only">
            <button class="btn btn-secondary" id="clear-all-mobile">
                <?php esc_html_e('Clear All', 'custom-theme'); ?>
            </button>
            <button class="btn btn-primary" id="apply-filters-mobile">
                <?php esc_html_e('Show Results', 'custom-theme'); ?>
            </button>
        </div>
    </div>

    <!-- Overlay for Mobile -->
    <div class="filters-overlay" id="filters-overlay"></div>

</div>