<?php
/**
 * Template part for displaying a product carousel
 *
 * Arguments:
 * - query: WP_Query object containing products
 * - title: String title for the carousel section
 *
 * @package Custom_Theme
 */

$carousel_query = $args['query'] ?? null;
$carousel_title = $args['title'] ?? 'Products';

if ($carousel_query && $carousel_query->have_posts()):
    ?>
    <div class="product-carousel-section">
        <div class="product-carousel-wrapper-premium">
            <!-- Header -->
            <div class="product-carousel-header">
                <h3 class="product-carousel-title"><?php echo esc_html($carousel_title); ?></h3>
                <div class="carousel-controls">
                    <button class="carousel-btn prev" aria-label="Previous">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="15 18 9 12 15 6"></polyline>
                        </svg>
                    </button>
                    <button class="carousel-btn next" aria-label="Next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Track -->
            <div class="product-carousel-track-wrapper">

                <!-- SKELETON LOADER OVERLAY (Premium Performance Layer) -->
                <div class="product-carousel-skeleton" aria-hidden="true">
                    <div class="skeleton-track">
                        <?php for ($i = 0; $i < 4; $i++): ?>
                            <div class="skeleton-card">
                                <div class="skeleton-image"></div>
                                <div class="skeleton-content">
                                    <div class="skeleton-line skeleton-meta"></div>
                                    <div class="skeleton-line skeleton-title"></div>
                                    <div class="skeleton-line skeleton-price"></div>
                                    <div class="skeleton-line skeleton-btn"></div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="product-carousel-track">
                    <?php
                    while ($carousel_query->have_posts()):
                        $carousel_query->the_post();
                        global $product;

                        // Data Extraction
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium_large');
                        $image_url = $image ? $image[0] : wc_placeholder_img_src();
                        $is_in_stock = $product->is_in_stock();
                        $average_rating = $product->get_average_rating();
                        $review_count = $product->get_review_count();
                        ?>

                        <!-- Product Card -->
                        <div class="carousel-product-card">
                            <!-- Image -->
                            <div class="carousel-card-image-wrapper">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php the_title_attribute(); ?>"
                                        class="carousel-card-image" loading="lazy">
                                </a>
                                <!-- Valid Badges -->
                                <?php if ($product->is_on_sale()): ?>
                                    <span class="card-badge sale">Sale</span>
                                <?php elseif (!$is_in_stock): ?>
                                    <span class="card-badge sale">Sold Out</span>
                                <?php endif; ?>
                            </div>

                            <!-- Content -->
                            <div class="carousel-card-content">
                                <div class="carousel-card-meta">
                                    <div class="stock-status <?php echo $is_in_stock ? 'in-stock' : 'out-of-stock'; ?>">
                                        <span class="stock-status-dot"></span>
                                        <?php echo $is_in_stock ? 'In Stock' : 'Out of Stock'; ?>
                                    </div>
                                    <?php if ($average_rating > 0): ?>
                                        <div class="rating">★ <?php echo number_format($average_rating, 1); ?></div>
                                    <?php endif; ?>
                                </div>

                                <h4 class="carousel-card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h4>

                                <div class="carousel-card-price">
                                    <?php echo $product->get_price_html(); ?>
                                </div>

                                <div class="carousel-card-actions">
                                    <?php if ($product->is_type('simple')): ?>
                                        <a href="<?php echo esc_url($product->add_to_cart_url()); ?>" data-quantity="1"
                                            class="btn-card-primary product_type_simple add_to_cart_button ajax_add_to_cart"
                                            data-product_id="<?php echo get_the_ID(); ?>"
                                            aria-label="Add to cart: <?php the_title_attribute(); ?>">
                                            <?php esc_html_e('Add to Cart', 'custom-theme'); ?>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php the_permalink(); ?>" class="btn-card-primary">
                                            <?php esc_html_e('Select Options', 'custom-theme'); ?>
                                        </a>
                                    <?php endif; ?>

                                    <!-- Quick View / Wishlist Mockup -->
                                    <button class="btn-card-icon" aria-label="Wishlist">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path
                                                d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z">
                                            </path>
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php
                    endwhile;
                    // Note: wp_reset_postdata() should be called by the caller, or here if we cloned the query.
                    // Since we pass the query object, it's safer to let the caller handle main query reset if needed,
                    // but for custom queries passed in, we usually iterate them. 
                    // To be safe and self-contained for custom queries:
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>