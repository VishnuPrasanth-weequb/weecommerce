<?php
/**
 * The template for displaying all single pages
 * 
 * Compatible with page builders while maintaining default styling
 *
 * @package Custom_Theme
 */

get_header();
?>

<main id="primary" class="site-main page-content-wrapper">
    <?php
    while (have_posts()):
        the_post();
        ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

            <?php
            // Only show page title on non-WooCommerce pages
            if (!is_checkout() && !is_cart() && !is_account_page()):
                ?>
                <header class="page-header container">
                    <h1 class="page-title">
                        <?php the_title(); ?>
                    </h1>
                </header>
            <?php endif; ?>

            <div class="page-content">
                <?php
                /* 
                 * the_content() - This is where page builders inject their content
                 * No container wrapper here to allow full-width layouts
                 */
                the_content();

                // Page links for paginated content
                wp_link_pages(
                    array(
                        'before' => '<div class="page-links container">' . esc_html__('Pages:', 'custom-theme'),
                        'after' => '</div>',
                    )
                );
                ?>
            </div>

            <?php
            // Only show comments on regular pages, not WooCommerce
            if (comments_open() || get_comments_number()):
                ?>
                <div class="container">
                    <?php comments_template(); ?>
                </div>
                <?php
            endif;
            ?>

        </article>

        <?php
    endwhile; // End of the loop
    ?>
</main>

<?php
get_footer();
