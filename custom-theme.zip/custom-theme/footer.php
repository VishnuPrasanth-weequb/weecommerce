<!-- Main content ends in individual templates (page.php, single.php, etc.) -->

<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-content">
            <!-- Column 1: Branding, Logo & Social -->
            <div class="footer-brand">
                <h3 class="footer-brand-name">Calmistry</h3>
                <p class="footer-brand-tagline">Crafting calm through thoughtfully designed soy candles and refined
                    fragrances—made to elevate quiet moments and modern living.</p>

                <div class="footer-social">
                    <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="currentColor">
                            <path
                                d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                        </svg>
                    </a>
                    <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="currentColor">
                            <path
                                d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                        </svg>
                    </a>
                    <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" aria-label="X (Twitter)">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="currentColor">
                            <path
                                d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                        </svg>
                    </a>
                    <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="currentColor">
                            <path
                                d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Column 2: Quick Links -->
            <div class="footer-column">
                <h4 class="footer-column-title">Quick Links</h4>
                <ul class="footer-menu">
                    <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                    <?php if (class_exists('WooCommerce')): ?>
                        <li><a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>">Shop</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo esc_url(home_url('/collections')); ?>">Collections</a></li>
                    <li><a href="<?php echo esc_url(home_url('/about')); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact Us</a></li>
                </ul>
            </div>

            <!-- Column 3: Customer Care -->
            <div class="footer-column">
                <h4 class="footer-column-title">Customer Care</h4>
                <ul class="footer-menu">
                    <li><a href="<?php echo esc_url(home_url('/returns')); ?>">Easy Returns</a></li>
                    <li><a href="<?php echo esc_url(home_url('/shipping')); ?>">Free Shipping</a></li>
                    <li><a href="<?php echo esc_url(home_url('/payments')); ?>">Secure Payments</a></li>
                    <li><a href="<?php echo esc_url(home_url('/authentic')); ?>">Authentic Candles</a></li>
                </ul>
            </div>

            <!-- Column 4: Policies -->
            <div class="footer-column">
                <h4 class="footer-column-title">Policies</h4>
                <ul class="footer-menu">
                    <li><a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a></li>
                    <li><a href="<?php echo esc_url(home_url('/terms-conditions')); ?>">Terms & Conditions</a></li>
                    <li><a href="<?php echo esc_url(home_url('/shipping-delivery')); ?>">Shipping & Delivery</a></li>
                    <li><a href="<?php echo esc_url(home_url('/return-refund')); ?>">Return & Refund</a></li>
                    <li><a href="<?php echo esc_url(home_url('/faqs')); ?>">FAQs</a></li>
                </ul>
            </div>
        </div>

        <!-- Policy Links Carousel -->
        <div class="footer-policy-carousel">
            <div class="policy-carousel-wrapper">
                <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>" class="policy-link">
                    Privacy Policy
                </a>
                <span class="policy-separator">•</span>
                <a href="<?php echo esc_url(home_url('/terms-conditions')); ?>" class="policy-link">
                    Terms & Conditions
                </a>
                <span class="policy-separator">•</span>
                <a href="<?php echo esc_url(home_url('/shipping-delivery')); ?>" class="policy-link">
                    Shipping & Delivery
                </a>
                <span class="policy-separator">•</span>
                <a href="<?php echo esc_url(home_url('/return-refund')); ?>" class="policy-link">
                    Return & Refund
                </a>
                <span class="policy-separator">•</span>
                <a href="<?php echo esc_url(home_url('/faqs')); ?>" class="policy-link">
                    FAQs
                </a>
            </div>
        </div>

        <!-- Footer Bottom Bar -->
        <div class="footer-bottom">
            <p class="footer-copyright">&copy; <?php echo date('Y'); ?> Calmistry. All rights reserved.</p>
            <p class="footer-credit">Designed and Developed By Weequb Technologies</p>
        </div>
    </div>
</footer>

<!-- Toast Container -->
<div id="toast-container" class="toast-container"></div>

<!-- Mobile Menu Drawer -->
<div class="mobile-menu-overlay"></div>
<div id="mobile-menu-drawer" class="mobile-menu-drawer">
    <div class="mobile-menu-header">
        <h3><?php esc_html_e('Menu', 'custom-theme'); ?></h3>
    </div>
    <div class="mobile-menu-content">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_class' => 'nav-menu',
            'container' => false,
            'fallback_cb' => function () {
                echo '<ul class="nav-menu">';
                echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';
                echo '<li><a href="' . esc_url(home_url('/about-us')) . '">About Us</a></li>';
                if (class_exists('WooCommerce')) {
                    echo '<li><a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '">Products</a></li>';
                }
                echo '<li><a href="' . esc_url(home_url('/contact-us')) . '">Contact Us</a></li>';
                echo '</ul>';
            }
        ));
        ?>
    </div>
</div>

<!-- Cart Drawer -->
<?php if (class_exists('WooCommerce')): ?>
    <div class="cart-overlay"></div>
    <div id="cart-drawer" class="cart-drawer">
        <div class="cart-drawer-header">
            <h3><?php esc_html_e('Your Cart', 'custom-theme'); ?></h3>
            <button class="cart-drawer-close" aria-label="<?php esc_attr_e('Close Cart', 'custom-theme'); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>
        </div>
        <div class="cart-drawer-content">
            <div class="widget_shopping_cart_content">
                <?php woocommerce_mini_cart(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php wp_footer(); ?>
</body>

</html>